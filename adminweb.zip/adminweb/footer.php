<footer id="footer">
    <div class="container">
    <div class="col-lg-12">
    <div class="row">
    <div class="col-lg-6">
      <div class="credits" style="line-height: 75px;float:left;;">
        
        <span style="font-size:17px;padding-right:10px;">Email:</span><a href="#">info@webakm.com</a>
      </div>
      </div>
      <div class="col-lg-6">
     
       <!-- <div class="copyright">
        &copy; Copyright <strong>Webakm</strong>. All Rights Reserved
      </div> -->
        <nav id="nav-menu-container" style="margin-top: 24px;">
        <ul class="nav-menu">
          <li><a href="#body">Home</a></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <!-- <li><a href="#team">Team</a></li> -->
          
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>

      </div>
      </div>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>
  <script src="lib/sticky/sticky.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>