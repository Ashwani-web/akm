<?php 





$con = mysqli_connect("localhost","root","123456","webakm"); 
//$con = mysqli_connect("localhost","webakm","webakm@12","webakm"); 

?>
