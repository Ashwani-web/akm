    
<html lang="en">
<head>
  <?php
include("db.php");
include('head.php');
?>

  
</head>

<body id="body">
<?php include('header.php');?>
  

  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">

    <div class="intro-content">
      <!-- <h2>Imagine and <span>Create</span><br></h2> -->
      <div>
        <a href="#about" class="btn-get-started scrollto">Get Started</a>
        <a href="#portfolio" class="btn-projects scrollto">Our Projects</a>
      </div>
    </div>

    <div id="intro-carousel" class="owl-carousel" >
      <!-- <div class="item" style="background-image: url('img/intro-carousel/b1.jpeg');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/b2.jpeg');"></div> -->
      <div class="item" style="background-image: url('img/intro-carousel/9.png');"></div>
      <div class="item" style="background-image: url('img/intro-carousel/10.jpg');"></div>
      <!-- <div class="item" style="background-image: url('img/intro-carousel/5.jpg');"></div> -->
    </div>

  </section><!-- #intro -->

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 about-img">
            <!--<img src="img/about-img.jpg" alt="">-->
            <img src="img/home_image.png" alt="">
          </div>

          <div class="col-lg-6 content">
           
            <h2>Our Expertise</h2>
            <p><b>We are committed to fulfill technology needs
of our clients</b></p>
            <ul>
            <li>We offer the following professional solutions within the structure of rigorous quality and project management processes to endorse successful projects and positive customer relationships.</li>
              <!-- <li><i class="ion-android-checkmark-circle"></i> Web Designing</li> -->
              <li><i class="ion-android-checkmark-circle"></i> Web Designing & Development</li>
              <li><i class="ion-android-checkmark-circle"></i> SEO and SMO</li>
              <li><i class="ion-android-checkmark-circle"></i> E-Commerce Solutions</li>
              <li><i class="ion-android-checkmark-circle"></i> CRM,MLM</li>
              <!-- <li><i class="ion-android-checkmark-circle"></i> Database Management System</li> -->
              <li><i class="ion-android-checkmark-circle"></i> Graphics and Logo  Designing </li>
            </ul>
            </ul>

          </div>
        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      Services Section
    ============================-->
    <section id="services">
      <div class="container">
        <div class="section-header">
          <h2>Our Services</h2>
           
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="box wow fadeInLeft">
              <div class="icon"><i class="fa fa-bar-chart"></i></div>
              <h4 class="title"><a href="">Web Designing</a></h4>
              <p class="description">We are a strong team of experienced, dedicated and passionate web designers and web developers.We don't just construct websites, we build websites that promotes your business to the right audience and expend your business.</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInRight">
              <div class="icon"><i class="fa fa-code"></i></div>
              <h4 class="title"><a href="">Web Development</a></h4>
              <p class="description">We offer unique and secure web application development solutions matching customer's business strategies and requirements. We collaborate with customers to understand your goals and deliver high-quality business value.</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInLeft" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-globe"></i></div>
              <h4 class="title"><a href="">Internet Marketing</a></h4>
              <p class="description">We help you build a robust digital marketing strategy that enables you to establish a powerful online presence and create engaging experience, so your customers can find you easily and take stimulated actions.</p>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="box wow fadeInRight" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-cart-plus"></i></div>
              <h4 class="title"><a href="">Ecommerce Solution</a></h4>
              <p class="description">We provides incredible services to e-commerce websites. Our e-commerce development experts have vast experience and expertise to provide the best CMS solution for ecommerce.&nbsp;&nbsp;</p></br>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- #services -->

    <!--==========================
      Clients Section
    ============================-->
    <style> .logop{
  padding:10px;
  margin:10px;

  }</style>
    <!-- <section id="clients" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Clients</h2>
          <p>Sed tamen tempor magna labore dolore dolor sint tempor duis magna elit veniam aliqua esse amet veniam enim export quid quid veniam aliqua eram noster malis nulla duis fugiat culpa esse aute nulla ipsum velit export irure minim illum fore</p>
        </div>

        <div class="owl-carousel clients-carousel">
         <img src="img/clients/booksyaari_logo.png" alt="" class="logop">
          <img src="img/clients/jeezapparel_logo.png" alt="" class="logop">
          <img src="img/clients/mulmul_logo.png" alt="" class="logop">
          <img src="img/clients/lokaci_logo.png" alt="" class="logop">
          <img src="img/clients/sb_logo.png" alt="" class="logop">
          <img src="img/clients/dinesh_logo.png" alt="" class="logop">
          <img src="img/clients/daruss_logo.png" alt="" class="logop">
          <img src="img/clients/mulmul_logo.png" alt="" class="logop">
        </div>

      </div>
    </section> --><!-- #clients -->

    <!--==========================
      Our Portfolio Section
    ============================-->
    <section id="portfolio" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2><!-- Our Portfolio -->OUR WORKS</h2>
         
        </div>
      </div>

      <div class="container-fluid">
        <div class="row no-gutters">
<?php 
  $view_posts = "select * from  portfolio limit 0 ,6  ";
  $run_posts = mysqli_query($con, $view_posts);
  while($row_posts = mysqli_fetch_array($run_posts)){ 
                          ?>
          <div class="col-lg-4 col-md-4" style="padding: 10px;">
            <div class="portfolio-item wow fadeInUp">
              <a href="img/portfolio/<?php echo $row_posts['p_image']; ?>" class="portfolio-popup TEST">
                <img src="img/portfolio/<?php echo $row_posts['p_image']; ?>" alt="123">
                <div class="portfolio-overlay">
                  <div class="portfolio-info">
                  <h2 class="wow fadeInUp"><?php echo $row_posts['p_name']; ?> </h2>
                  
                  </div>
                  </div>
              </a>

            </div>
<a href="<?php echo $row_posts['p_url']; ?>" target="_blank" ><span style="margin-left:115px;"><?php echo $row_posts['p_name']; ?></span></a>
          </div>
          <?php } ?>

             

        </div>

      </div>
    </section><!-- #portfolio -->

    <!--==========================
      Testimonials Section
    ============================-->
    <section id="testimonials" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Testimonials</h2>
           
        </div>
        <div class="owl-carousel testimonials-carousel">
        <?php 
  $view_posts = "select * from  testimonials limit 0 ,3  ";
  $run_posts = mysqli_query($con, $view_posts);
  while($row_posts = mysqli_fetch_array($run_posts)){ 
                          ?>

            <div class="testimonial-item">
              <p style="margin-top: 30px;">
                <img src="img/quote-sign-left.png" class="quote-sign-left" alt="">
                <?php echo $row_posts['testimonial_content'];?>
                <img src="img/quote-sign-right.png" class="quote-sign-right" alt="">
              </p>
              <!-- <img src="img/testimonial-1.jpg" class="testimonial-img" alt=""> -->
              <h3><?php echo $row_posts['testimonial_u_name'];?> </h3>
              <h4><?php echo $row_posts['t_position'];?></h4>
            </div>
            <?php } ?>

               
 

        </div>

      </div>
    </section><!-- #testimonials -->

    <!--==========================
      Call To Action Section
    ============================-->
    <!-- <section id="call-to-action" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-left">
            <h3 class="cta-title">Call To Action</h3>
            <p class="cta-text"> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#">Call To Action</a>
          </div>
        </div>

      </div>
    </section> --><!-- #call-to-action -->

    <!--==========================
      Our Team Section
    ============================-->
    <!-- <section id="team" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Our Team</h2>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6">
            <div class="member">
              <div class="pic"><img src="img/team-1.jpg" alt=""></div>
              <div class="details">
                <h4>Walter White</h4>
                <span>Chief Executive Officer</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="member">
              <div class="pic"><img src="img/team-2.jpg" alt=""></div>
              <div class="details">
                <h4>Sarah Jhinson</h4>
                <span>Product Manager</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="member">
              <div class="pic"><img src="img/team-3.jpg" alt=""></div>
              <div class="details">
                <h4>William Anderson</h4>
                <span>CTO</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="member">
              <div class="pic"><img src="img/team-4.jpg" alt=""></div>
              <div class="details">
                <h4>Amanda Jepson</h4>
                <span>Accountant</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section> --><!-- #team -->

    <!--==========================
      Contact Section
    ============================-->







    <section id="contact" class="wow fadeInUp">
      <div class="container">
      <div class="section-header">
          <h2>Contact Us</h2>
           
        </div>
<div class="row">
<div class="col-md-9">
<div class="container">
        <div class="form">
          <div id="sendmessage">Your message has been sent. Thank you!</div>
          <div id="errormessage"></div>
          <?php if(isset($_GET['email']) && $_GET['email'] == 'success'){ ?>
        <script type="text/javascript">
            alert('Thank you, mail has been sent successfuly. We will contact you soon.');
             
        </script>
    <?php } ?>
          <form action="" method="post" role="form" class="contactForm">
            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
              <div class="form-group col-md-6">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
              <div class="validation"></div>
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
              <div class="validation"></div>
            </div>
            <div class="text-center"><button type="submit">Send Message</button></div>
          </form>
        </div>



      </div>
</div>
<div class="col-md-3">
<div class="row contact-info">

         <!--  <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Address</h3>
              <address></address>
            </div>
          </div> -->

          <div class="col-md-12">
            <!-- <div class="contact-phone"> -->
              <div class="">
              <!-- <h3>Phone Number</h3> -->
              <p><strong> Contact No : </strong>  </strong>  <a href="tel:+">+91-9560410376</a></p>
            </div>
          </div>

          <div class="col-md-12">
            <div class="contact-email">
               <!-- <i class="ion-ios-email-outline"></i> -->
             <!--  <h3>Email</h3> -->
              <p><strong>  Email : </strong>  <a href="mailto:info@webakm.com">info@webakm.com</a></p>
            </div>
          </div>

        </div>
      </div>

</div>
</div>
</div>
         

        

      

      
    </section>




    <!-- #contact -->

  </main>
<?php include('footer.php');?>
  <!--==========================
    Footer
  ============================-->
  

</body>
</html>


