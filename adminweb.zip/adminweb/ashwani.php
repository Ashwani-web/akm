<!DOCTYPE html>
<html lang="en">
<head>
  <?php
include("db.php");
include('head.php');
?>

  
</head>

<body id="body">
<?php //include('header.php');?>
  

  <!--==========================
    Intro Section
  ============================-->
 

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          

          <div class="col-lg-8 content">
           
            <h2>Hi,</h2>
            <p></p>
            <ul>
            <li>My name is <b> Ashwani kumar Maurya</b> and I am working as Team leader in enthuons technologies . I am a fullstack developer with having knowledge of PHP, Laravel, Magento, Wordpres.</li>
              <!-- <li><i class="ion-android-checkmark-circle"></i> Web Designing</li> -->
              <li><i class="ion-android-checkmark-circle"></i> Web Designing & Development</li>
              <li><i class="ion-android-checkmark-circle"></i> SEO and SMO</li>
              <li><i class="ion-android-checkmark-circle"></i> E-Commerce Solutions</li>
              <li><i class="ion-android-checkmark-circle"></i> CRM,MLM</li>
              <!-- <li><i class="ion-android-checkmark-circle"></i> Database Management System</li> -->
              <li><i class="ion-android-checkmark-circle"></i> Graphics and Logo  Designing </li>
            </ul>
            </ul>

          </div>
          
          <div class="col-lg-4 about-img">
            <!--<img src="img/about-img.jpg" alt="">-->
            <img src="img/ak.jpg" alt="" style="transform: rotate(89deg);
    margin-top: 144px;">
          </div>
          
          
          
          
        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      Services Section
    ============================-->
     
    






    <section id="contact" class="wow fadeInUp">
      <div class="container">
      <div class="section-header">
          <h2>Contact Us</h2>
           
        </div>
<div class="row">
<div class="col-md-9">
<div class="container">
        <div class="form">
          <div id="sendmessage">Your message has been sent. Thank you!</div>
          <div id="errormessage"></div>
          <form action="" method="post" role="form" class="contactForm">
            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
              <div class="form-group col-md-6">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
              <div class="validation"></div>
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
              <div class="validation"></div>
            </div>
            <div class="text-center"><button type="submit">Send Message</button></div>
          </form>
        </div>



      </div>
</div>
<div class="col-md-3">
<div class="row contact-info">

         <!--  <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Address</h3>
              <address></address>
            </div>
          </div> -->

          <div class="col-md-12">
            <!-- <div class="contact-phone"> -->
              <div class="">
              <!-- <h3>Phone Number</h3> -->
              <p><strong> Contact No : </strong>  </strong>  <a href="tel:+">+91-9560410376</a></p>
            </div>
          </div>

          <div class="col-md-12">
            <div class="contact-email">
               <!-- <i class="ion-ios-email-outline"></i> -->
             <!--  <h3>Email</h3> -->
              <p><strong>  Email : </strong>  <a href="mailto:info@webakm.com">info@webakm.com</a></p>
            </div>
          </div>

        </div>
      </div>

</div>
</div>
</div>
         

        

      

      
    </section>




    <!-- #contact -->

  </main>
<?php //include('footer.php');?>
  <!--==========================
    Footer
  ============================-->
  

</body>
</html>
