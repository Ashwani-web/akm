<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
             <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">

<h3 style="text-align: center; padding: 15px; background-color: #2b4055; color: #fff;">Register Student<a href="csv.php" class="btn btn-success pull-right">Download csv</a></h3>

                  <div class="x_content">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>Sn.</th>
                          <th>Student Name</th>
                          <th>Student Email</th>
                          <th>Student Contact</th>
                          <th>Date</th>
                          
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php 
                                $i=1;
                                $view_posts = "select * from  std_registration where status='1' ";
				$run_posts = mysqli_query($con, $view_posts);
				 while($row_posts = mysqli_fetch_array($run_posts)) {
                            ?>
                        <tr>
                          <td><?php echo $i++ ?></td>
                          <td><?php echo $row_posts['st_name']; ?></td>
                          <td><?php echo $row_posts['st_email']; ?></td>
                          <td><?php echo $row_posts['st_contact']; ?></td>
                          <td><?php echo $row_posts['created_on']; ?></td>
                          <td>
                      <a href="edit_register_student.php?st_id=<?php echo $row_posts['st_id']; ?>"><img src="images/edit.png"></a>
                           &nbsp;
                      <a href="delete.php?st_id=<?php echo $row_posts['st_id']; ?>" onclick="return confirm('Are you sure you want to delete ??');"><img src="images/delete.png"></a>
  
                        </td> 
                        </tr> 
                       <?php } ?> 
                     </tbody>
                    </table> 
                  </form> 
                  </div>
                </div>
              </div>
             </div>
            </div>
          </div>
        </div>
         <?php include("footer.php");?>
