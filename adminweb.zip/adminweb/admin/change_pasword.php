<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

<?php
if(isset($_POST['password_update'])){
        $pass_id = $_SESSION['id_admin'];
        $pwd = $_POST['pwd'];
        $newpassword = $_POST['newpassword'];
        $confirmnewpassword = $_POST['confirmnewpassword'];
		
		$view_pwd = "select * from admin_login WHERE password = '$pwd' ";
		
	    $run_pwd = mysqli_query($con, $view_pwd);
	
	    if($row_posts = mysqli_fetch_array($run_pwd)){
		
        if($newpassword==$confirmnewpassword){

 		$update_query = "update admin_login set password = '$newpassword' where id = '$pass_id' ";

		$update_run = mysqli_query($con, $update_query);
		
		header("location:logout.php");
		
		}
		else {
		echo "<script>alert('your new password do not match')</script>";
		}}
		else{
		echo "<script>alert('your old password do not match')</script>";
		}
}
    
?>


 <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Change Password </h3> 
   <br/>                    
   <br/> 
   <br/>     
              
<form method="post" class="form-horizontal form-label-left" enctype="multipart/form-data">
<br>   
<div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Old Password <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="password" name="pwd" class="form-control" placeholder="Enter Old Password" required />
                        </div>
                      </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">New Password  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                 <input type="password" name="newpassword" class="form-control" placeholder="New Password" required/>                     
                  
        </div>
                      </div>
  <div class="form-group">
             <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Confirm New Password <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="password" name="confirmnewpassword" class="form-control" placeholder="Confirm New Password" required />
 
                        </div>
                      </div>
   
                       <br>      
                     <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <a href="index.php" class="btn btn-primary">Cancel</a>
			  
                          <button type="submit" class="btn btn-success" name="password_update">Submit</button>
                        </div>
                      </div>
<br>  
<br>  
<br> 
                    </form>



 


<br/>  
<br/>  
<br/>                 
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

