<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             
 
  <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <h3 style="text-align: center; padding: 15px; background-color: #2b4055; color: #fff;">Campaign Data</h3> 
                  <div class="x_content">
                    
                    <table id="datatable" class="table table-striped table-bordered mytable">
                      <thead>
                        <tr>
                          <th>Sn.</th>
                          <th> Name</th>
                          <th>Email ID</th>
                          <th>Contact</th>
                           <th>State</th>
                          <th>City</th>
                          <th>Course</th>
                          </tr>
                      </thead>


                      <tbody>
                           <?php 
                                $i=1;
                                $view_posts = "select * from  campaign_data  ";
				 $run_posts = mysqli_query($con, $view_posts);
				 while($row_posts = mysqli_fetch_array($run_posts))
{
			   ?>
                        <tr>
                          <td><?php echo $i++ ?></td>
                          <td><?php echo $row_posts['name']; ?></td>
                        
                          <td><?php echo $row_posts['email_id']; ?></td>
                          <td><?php echo $row_posts['contact_no']; ?></td>
                          <td><?php echo $row_posts['state']; ?></td>
                          <td><?php echo $row_posts['City']; ?></td>
                          <td><?php echo $row_posts['Course']; ?></td>
                       </tr>

 
                        
                        <?php } ?>
                        
                         
                      </tbody>
                    </table>










 
                    </form>
 
                  </div>
                </div>
              </div>
 
              </div>
  
            </div>
          </div>
        </div>
         <?php include("footer.php");?>
<style>
.mytable tbody tr td{
  max-width:240px; /* Customise it accordingly */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}


</style>
