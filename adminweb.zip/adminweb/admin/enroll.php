<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

<script>
function validate(){
var mobile_no=document.myform.mobile_no.value;
if (isNaN(mobile_no)){
  document.getElementById("numloc").innerHTML="Enter Numeric value only";
  return false;
}
else{  
   return true;  
  }  
}
</script>
 

<?php



if(isset($_POST['enroll_submit'])){
$image = $_FILES['image']['name'];
$image_tmp1 = $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp1, "user-images/$image");
//$profile_image = $_POST['profile_image'];
$f_name = $_POST['f_name'];	
$m_name = $_POST['m_name'];
$l_name = $_POST['l_name'];
$dob = $_POST['dob'];
$name_of_place = $_POST['name_of_place'];
$gender = $_POST['gender'];
$marital_status = $_POST['marital_status'];
$address = $_POST['address'];
$city = $_POST['city'];
$state_a = $_POST['state_a'];
$zip = $_POST['zip'];
$mobile_no = $_POST['mobile_no'];
$your_email = $_POST['your_email'];
$citizen_of_india = $_POST['citizen_of_india'];
$date_of_result = $_POST['date_of_result'];
$name_of_examination = $_POST['name_of_examination'];

$year_passing = $_POST['year_passing'];
$board_university = $_POST['board_university'];
$of_marks = $_POST['of_marks'];
$name_of_examination_12 = $_POST['name_of_examination_12'];
$year_passing_12 = $_POST['year_passing_12'];
$board_university_12 = $_POST['board_university_12'];
$of_marks_12 = $_POST['of_marks_12'];
$name_of_examination_10 = $_POST['name_of_examination_10'];

$year_passing_10 = $_POST['year_passing_10'];
$board_university_10 = $_POST['board_university_10'];
$of_marks_10 = $_POST['of_marks_10'];
$stream_applied = $_POST['stream_applied'];
$amount = $_POST['amount'];
$payment_details = $_POST['payment_details'];
//$dd_no = $_POST['dd_no'];
$paying_by = $_POST['paying_by'];
$dd_date = $_POST['dd_date'];

$bank_name = $_POST['bank_name'];
$payable_at = $_POST['payable_at'];
$gurdian_name = $_POST['gurdian_name'];
$phone_no = $_POST['phone_no'];
$parent_email = $_POST['parent_email'];
$parent_address = $_POST['parent_address'];
$parent_occupations = $_POST['parent_occupations'];
$parent_annualincome = $_POST['parent_annualincome'];

$i_hereby = $_POST['i_hereby'];
$date_final = $_POST['date_final'];
$place_final = $_POST['place_final'];
$applicant_signature = $_POST['applicant_signature'];
$your_message = $_POST['your_message'];
$status = $_POST['status'];
 


//setcookie($f_name, $cookie_value,$l_name, time() + (86400 * 30), "/");


 



$insert_details = "insert into  enrolment_master (profile_image,f_name,m_name,l_name,dob,name_of_place,gender,marital_status,address,city,state_a,zip,mobile_no,your_email,citizen_of_india,
date_of_result,name_of_examination,year_passing,board_university,of_marks,name_of_examination_12,year_passing_12,board_university_12,
of_marks_12,name_of_examination_10,year_passing_10,board_university_10,of_marks_10,stream_applied,amount,payment_details,paying_by,dd_date,
bank_name,payable_at,gurdian_name,phone_no,parent_email,parent_address,parent_occupations,parent_annualincome,i_hereby,date_final,place_final,
applicant_signature,your_message,status,created_on) 
values ('$image','$f_name','$m_name','$l_name','$dob','$name_of_place','$gender','$marital_status','$address','$city','$state_a','$zip',
'$mobile_no',
'$your_email','$citizen_of_india','$date_of_result','$name_of_examination','$year_passing','$board_university','$of_marks','$name_of_examination_12',
'$year_passing_12','$board_university_12','$of_marks_12','$name_of_examination_10','$year_passing_10','$board_university_10','$of_marks_10',
'$stream_applied','$amount','$payment_details','$paying_by','$dd_date','$bank_name','$payable_at','$gurdian_name','$phone_no','$parent_email',
'$parent_address','$parent_occupations','$parent_annualincome','$i_hereby','$date_final','$place_final','$applicant_signature',
'$your_message','$status',NOW()) ";

 
//$insert_details="CALL st_insert('$st_name','$st_email','$st_contact','$st_password','','')";

$run_insert = mysqli_query($con, $insert_details);
if($run_insert){
//echo "<script>location.href='enroll.php'</script>";
}
else{
echo "<script>alert('Error!!')</script>";
}
}
?>


<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Student Register </h3> 
     
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data" name="myform"  onsubmit="return validate()">
  
 <input type="file" name="image"  placeholder="Profile image" value="">
 <input type="text" class="form-control" name="f_name"   placeholder="First name" value="" >
 <input type="text" class="form-control" name="m_name"   placeholder="Middle name" value="">
  <input type="text" class="form-control" name="l_name" placeholder="Last name" value="">
  <input type="text" class="form-control" name="dob"  placeholder="DOB" value="">
  <input type="text" class="form-control" name="name_of_place" placeholder="Place" value="" required="">
  <label class="radio-inline"> <input type="radio" name="gender" value="male" checked="">Male</label>
  <label class="radio-inline"> <input type="radio" name="gender" value="female">Female</label>
   
   <label class="radio-inline"><input type="radio" name="marital_status" value="Married" checked="">Married</label>
   <label class="radio-inline"><input type="radio" name="marital_status" value="Un-married">Un-married</label>
   <input type="text" name="address"   class="form-control" placeholder="Address" value="">
   <input type="text" name="city"   class="form-control" placeholder="city" value="" required="">
   <select name="state_a" class="form-control">
<option>Choose State</option>
<option value="Andra Pradesh">Andra Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Goa">Goa</option>

<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>

<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madya Pradesh">Madya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>


<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Rajasthan">Rajasthan</option>

<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Tripura">Tripura</option>
<option value="Uttaranchal">Uttaranchal</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>

<option value="West Bengal">West Bengal</option>
<option value="Andaman and Nicobar">Andaman and Nicobar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>

<option value="Delhi">Delhi</option>
<option value="Lakshadeep">Lakshadeep</option>
<option value="Pondicherry">Pondicherry</option>
 


</select>



<input type="text" name="zip"   class="form-control" placeholder="zip" value="">
<input type="text" name="mobile_no"   class="form-control" placeholder="Phone mobile" value="" required=""><span id="numloc"></span>

 <input type="email" name="your_email"   class="form-control" placeholder="Your email" value="" >
 <label class="radio-inline"><input type="radio" name="citizen_of_india" value="Yes" checked="">Yes</label>
 <label class="radio-inline"><input type="radio" name="citizen_of_india" value="No">No</label>
	
	<input type="text" name="date_of_result" id="datepicker2"  class="form-control hasDatepicker" placeholder="Date of result" value="">

	<table class="table-responsive table table-bordered">
                    <thead>
                      <tr>
                        <th>NAME OF EXAMINATION PASSED</th>
                        <th>YEAR PASSING</th>
                        <th>BOARD/UNIVERSITY</th>
                        <th>% OF MARKS</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><input type="text" name="name_of_examination" class="form-control" placeholder="Graduation" value="" size="40"></td>
                        <td><input type="text" name="year_passing" value="" id="datepicker3" class="form-control hasDatepicker"></td>
                        <td><input type="text" name="board_university" class="form-control" value="" size="40"></td>
                        <td><input type="text" name="of_marks" class="form-control"   value="">
                         </td>
                      </tr>
                      <tr>
                        <td><input type="text" name="name_of_examination_12" class="form-control" placeholder="12th" value="" size="40"></td>
                        <td><input type="text" name="year_passing_12" class="form-control hasDatepicker" id="datepicker4" value=""></td>
                        <td><input type="text" name="board_university_12" class="form-control" value="" size="40"></td>
                        <td><input type="text" name="of_marks_12" class="form-control"  value="">
                         </td>
                      </tr>
                      <tr>
                        <td><input type="text" name="name_of_examination_10" class="form-control" placeholder="10th" value="" size="40"></td>
                        <td><input type="text" name="year_passing_10" class="form-control hasDatepicker" id="datepicker5" value=""></td>
                        <td><input type="text" name="board_university_10" class="form-control" value="" size="40"></td>
                        <td><input type="text" name="of_marks_10" class="form-control" value="">
                         </td>
                      </tr>
                    </tbody>
                  </table>

<label class="radio-inline">
    <input type="radio" name="stream_applied" value="Mechanical" checked="">Mechanical</label>
	<label class="radio-inline"> <input type="radio" name="stream_applied" value="Avionics">Avionics</label>
	<input type="text" class="form-control" name="amount" value="" placeholder="Application fee" required="">
				  
				  
	
	<input type="radio" name="payment_details"  value="dd">DD</label> <label class="radio-inline"> 
    <input type="radio" name="payment_details"   value="Online" checked="">Online</label>
	<input type="text" name="paying_by"   class="form-control" placeholder="DD no" value="">
	<input type="text" name="dd_date"   class="form-control " placeholder="DD Date" value="">
	 <input type="text" name="bank_name"   class="form-control" placeholder="Bank name" value="">
	 <input type="text" name="payable_at"   class="form-control" placeholder="Payable at" value="">
	 <input type="text" name="gurdian_name"   class="form-control" placeholder="Name of Parent/ Guardian" value="">
	 <input type="text" name="phone_no"   class="form-control" placeholder="Phone no" value="" required="">
	  <input type="text" name="parent_email" class="form-control" placeholder="Email" value="">
	  <input type="text" name="parent_address" class="form-control" placeholder="Address" value="">
	   <input type="text" name="parent_occupations" class="form-control" placeholder="Occupations">
	   <input type="text" name="parent_annualincome" class="form-control" placeholder="Parent annual income" value="">
           <input type="text" name="i_hereby" class="form-control" placeholder="Declare " value="">
	   <input type="text" name="date_final" class="form-control hasDatepicker" placeholder="Date" value="">
	   <input type="text" name="place_final"   class="form-control" placeholder="place" value="">
	   <input type="text" name="applicant_signature"   class="form-control" placeholder="Signature" value="">
	   <input type="text" name="your_message"   class="form-control" placeholder="Type your message" value="">
	   <input type="hidden" name="status"   class="form-control" placeholder="Type your message" value="">
	   <input type="submit" name="enroll_submit" style="margin-top:2%;" class="btn " value="Submit Now"></div>

 
         </form>
        
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

