-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 31, 2017 at 01:56 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `same`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `user_name`, `password`, `role`) VALUES
(1, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL,
  `blog_name` varchar(999) NOT NULL,
  `blog_content` varchar(9999) NOT NULL,
  `blog_image` varchar(9999) NOT NULL,
  `post_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `blog_name`, `blog_content`, `blog_image`, `post_date`) VALUES
(1, 'Aviation Industry â€“ Enter the aisle with numerous careers', 'Aviation Industry â€“ Enter the aisle with numerous careers', '1.jpg', '2017-10-31 12:14:36'),
(2, 'Choose the career of your choice in aviation', 'Today the most challenging phase in a youthâ€™s life is the choice of the right field or course after 10+2. Seldom we findyoung minds set with the choice of the field aspired, dreamt of since childhood.\r\nIn this competitive era, educationalists are using innovative, modern teaching aids to cater the attention of the youth for building up their strong future. Will it suffice the search of the youth today, which is graced with innovative cognitive abilities, constantly seeking more sophisticated learning and career.\r\n<b>Government organizations </b>are still continuing with their traditional courses wrapped with same teaching methodologies.The private organizations on the other hand is coming up with new, creative, rational learning methods. Precisely in todayâ€™s era youth too is seeking more logistic learning, practically encompassed teaching aids. Next quest is to know their Return On Investment in terms of remuneration after placement i.e. return on investment on the course of their efforts. Undoubtedly, no one refutes the fact that this is a tricky and yet inevitable question seeking an answer which again is subjective to innumerable factors, constant and variable. However, to figure out the future prospects of any field in a career one needs to be foresighted i.e. to visualize, analyse the market scenario ahead of time.\r\nOne such course that is emerging now as a boost to career in aviation is Aircraft Maintenance Engineeringis known as an AME course. Needless to say that as other courses have apprehensions this too, but what makes it unique and competitive is its growing demand in the rapidly growing aviation market.\r\nSafety is very important, when it comes to aviation sector. An aircraft is made of numerous parts, engines, electrical and electronic systems, etc. With time and use, parts tend to wear and tear down. Regular inspection and maintenance of aircraft have thus becomevery necessary. Aircraft Maintenance Engineering professionals are trained to inspect an aircraft, diagnose problems, report the problems found and finally solve them.\r\nBefore a flight takes off, AME professionals work hard and make sure that each and every system available in the aircraft is in working condition. They ensure that the safety standards are being followed and the aircraft is flightworthy. In short, AME professionals play a very crucial role in the smooth functioning of aviation sector!\r\nAfter gaining complete insight about the AME course, one needs to expedite for the best AME college in India or top AME institutes, also to ensure the AME institute is duly approved by DGCA.\r\nWhatâ€™s next is the outcome, the career.AME career prospects in India after completion of the AME course& acquiring BAMEEC is tremendously huge in India and abroad.The demand for an AME in the aviation jobs in India is unceasingly increasing due to the high passenger flow in air travel directly leading to the increase in the number fleets by the respective airlines.\r\nTo start with, an AME works as an Aircraft Technician, Junior Trainee / Engineer in an airline, an aviation related IT organization or an MRO.\r\nWho can be a better judge than we ourself to know us first, our aim and interests in life. For building up the career in aviation,let us exercise to gather some updated facts to have complete understanding about the aviation industry in India. After all, the future prospects are directly proportionate to the steps we take today.', 'thumb-airport-2.jpg', '2017-10-31 12:15:25'),
(3, 'School for Aircraft Maintenance Engineering (SAME)', 'School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)', 'slide1.jpg', '2017-10-31 12:16:08'),
(4, 'School for Aircraft Maintenance Engineering (SAME)', 'School for Aircraft Maintenance Engineering (SAME)', 'banner.jpg', '2017-10-31 12:46:02'),
(5, 'School for Aircraft Maintenance Engineering (SAME)', 'School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)School for Aircraft Maintenance Engineering (SAME)', '', '2017-10-30 18:48:28'),
(6, 'School for Aircraft Maintenance Engineering (SAME)', 'School for Aircraft Maintenance Engineering (SAME)', '', '2017-10-30 18:50:58'),
(8, 'School for Aircraft Maintenance Engineering (SAME)', 'School for Aircraft Maintenance Engineering (SAME)', '', '2017-10-30 19:01:52'),
(9, 'Aviation Industry', 'Aviation Industry', '', '2017-10-31 10:43:54'),
(10, 'Aviation Industry', 'Aviation Industry', '', '2017-10-31 10:49:14'),
(11, 'Aviation Industry â€“ Enter the aisle with numerous careers', 'Aviation Industry â€“ Enter the aisle with numerous careers', '', '2017-10-31 11:00:40'),
(12, 'blog_image', 'blog_image', '', '2017-10-31 11:02:39'),
(14, 'Aviation Industry â€“ Enter the aisle with numerous careers', 'Aviation Industry â€“ Enter the aisle with numerous careers', '1.jpg', '2017-10-31 11:13:25'),
(15, 'Aviation Industry â€“ Enter the aisle with numerous careers', 'Aviation Industry â€“ Enter the aisle with numerous test', 's1.jpg', '2017-10-31 12:04:59');

-- --------------------------------------------------------

--
-- Table structure for table `enrolment_master`
--

CREATE TABLE `enrolment_master` (
  `En_id` int(11) NOT NULL,
  `St_id` int(11) NOT NULL,
  `profile_image` varchar(9999) DEFAULT NULL,
  `f_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `m_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `l_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `name_of_place` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `gender` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `marital_status` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `state_a` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `phone_mobile` varchar(15) DEFAULT NULL,
  `your_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `citizen_of_india` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `date_of_result` varchar(30) DEFAULT NULL,
  `name_of_examination` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `year_passing` varchar(30) DEFAULT NULL,
  `board_university` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `of_marks` varchar(20) DEFAULT NULL,
  `name_of_examination_12` varchar(100) NOT NULL,
  `year_passing_12` varchar(20) NOT NULL,
  `board_university_12` varchar(100) NOT NULL,
  `of_marks_12` varchar(20) NOT NULL,
  `name_of_examination_10` varchar(100) NOT NULL,
  `year_passing_10` varchar(20) NOT NULL,
  `board_university_10` varchar(100) NOT NULL,
  `of_marks_10` varchar(20) NOT NULL,
  `stream_applied` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_details` varchar(20) DEFAULT NULL,
  `dd_no` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `dd_date` varchar(30) DEFAULT NULL,
  `bank_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `payable_at` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `gurdian_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `parent_email` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `parent_address` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_occupations` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_annualincome` varchar(20) DEFAULT NULL,
  `i_hereby` varchar(999) NOT NULL,
  `date_final` varchar(30) DEFAULT NULL,
  `place_final` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `applicant_signature` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `your_message` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gallery_id` int(11) NOT NULL,
  `g_name` varchar(999) NOT NULL,
  `image_name` varchar(9999) NOT NULL,
  `post_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gallery_id`, `g_name`, `image_name`, `post_date`) VALUES
(1, 'Test', 'svc2.jpg', '2017-10-31 15:47:58');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `news_name` varchar(250) NOT NULL,
  `news_image` varchar(9999) NOT NULL,
  `news_url` varchar(250) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_name`, `news_image`, `news_url`, `status`, `post_date`) VALUES
(1, 'Inside hari marars plan to make', '1.jpg', 'http://www.aviationindia.net/2017/10/inside-hari-marars-plan-to-make.html', 0, '2017-10-31 14:42:28'),
(2, 'Soon seaplanes to take flight in india', '', 'http://www.aviationindia.net/2017/10/soon-seaplanes-to-take-flight-in-india.html', 0, '2017-10-28 14:29:02'),
(3, 'Vistara wants to fly overseas by May next year', '', 'http://www.aviationindia.net/2017/09/vistara-wants-to-fly-overseas-by-may.html', 0, '2017-10-28 14:46:11');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notice_id` int(11) NOT NULL,
  `notice_name` varchar(250) NOT NULL,
  `notice_image` varchar(9999) NOT NULL,
  `notice_content` varchar(999) NOT NULL,
  `post_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notice_id`, `notice_name`, `notice_image`, `notice_content`, `post_date`) VALUES
(1, 'Aircraft Maintenance Engineers', '3.jpg', 'Aircraft Maintenance Engineers', '2017-10-31 14:15:07'),
(2, 'Aviation Industry', 'slider_1_1.jpg', 'Aviation Industry', '2017-10-31 14:14:20');

-- --------------------------------------------------------

--
-- Table structure for table `std_registration`
--

CREATE TABLE `std_registration` (
  `st_id` int(11) NOT NULL,
  `st_name` varchar(50) NOT NULL,
  `st_email` varchar(50) NOT NULL,
  `st_contact` varchar(15) NOT NULL,
  `st_password` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_registration`
--

INSERT INTO `std_registration` (`st_id`, `st_name`, `st_email`, `st_contact`, `st_password`, `created_on`, `status`) VALUES
(1, 'Ashwani', 'a@gmail.com', '9876543210', '1234', '2017-10-31 17:02:31', 1),
(2, 'HDI', 'hdi@gmail.com', '9876543212', '1234', '2017-10-31 17:32:38', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `enrolment_master`
--
ALTER TABLE `enrolment_master`
  ADD PRIMARY KEY (`En_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gallery_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `std_registration`
--
ALTER TABLE `std_registration`
  ADD PRIMARY KEY (`st_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `enrolment_master`
--
ALTER TABLE `enrolment_master`
  MODIFY `En_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `gallery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `std_registration`
--
ALTER TABLE `std_registration`
  MODIFY `st_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
