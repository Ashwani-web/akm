<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             
 
  <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <h3 style="text-align: center; padding: 15px; background-color: #2b4055; color: #fff;">Gallery<a href="gallery.php" class="btn btn-success pull-right">Add Gallery</a></h3> 
                  <div class="x_content">
                    
                    <table id="datatable" class="table table-striped table-bordered mytable">
                      <thead>
                        <tr>
                          <th>Sn.</th>
                          <th>Gallery  Name</th>
                          <th>Category Name</th>
                          <th>Gallery  Image</th>
                          
                           <th>Date</th>
                          <th>Action</th>
                          </tr>
                      </thead>


                      <tbody>
                           <?php 
                                $i=1;
                               // $view_posts = "select * from  gallery where parent_id='0'  ";
                                $view_posts = "SELECT gc.g_name as category_name,gsc.g_name as sub_category,gsc.image_name,gc.post_date,gsc.gallery_id FROM gallery gc,gallery gsc WHERE gc.gallery_id=gsc.parent_id ";
				 $run_posts = mysqli_query($con, $view_posts);
				 while($row_posts = mysqli_fetch_array($run_posts))
{
			   ?>
                        <tr>
                          <td><?php echo $i++ ?></td>
                          <td><?php echo $row_posts['sub_category']; ?></td>
                          <td><?php echo $row_posts['category_name']; ?></td>
                         
                          <td> <img src="gallery-images/<?php echo $row_posts['image_name']; ?>" style="width:120px;text-align:center;"></td>
                          <td><?php echo $row_posts['post_date']; ?></td>
                          <!--td><?php echo $row_posts['status']; ?></td-->
                          <td>
                           <a href="edit_gallery.php?gallery_id=<?php echo $row_posts['gallery_id']; ?>"><img src="images/edit.png"></a>
                           &nbsp;
                            <a href="delete.php?gallery_id=<?php echo $row_posts['gallery_id']; ?>" onclick="return confirm('Are you sure, you want to delete ??');"><img src="images/delete.png"></a>
                        </td>
                       </tr>

 
                        
                        <?php } ?>
                        
                         
                      </tbody>
                    </table>










 
                    </form>
 
                  </div>
                </div>
              </div>
 
              </div>
  
            </div>
          </div>
        </div>
         <?php include("footer.php");?>
<style>
.mytable tbody tr td{
  max-width:240px; /* Customise it accordingly */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}


</style>
