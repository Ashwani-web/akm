<?php include("db.php");


if(isset($_GET['p_id'])){
	
	$news_id = $_GET['p_id'];
	
	$delete_posts = "delete from portfolio where p_id = '$p_id' ";
	$run_delete = mysqli_query($con, $delete_posts);
	
	if($run_delete){
		
		header("location:view_portfolio.php");		
		}	
	}
	

	if(isset($_GET['blog_id'])){
	
	$blog_id = $_GET['blog_id'];
	
	$delete_posts = "delete from blog where blog_id = '$blog_id' ";
	$run_delete = mysqli_query($con, $delete_posts);
	
	if($run_delete){
		
		header("location:view_blog.php");		
		}	
	}
	


if(isset($_GET['notice_id'])){
	
	$notice_id = $_GET['notice_id'];

	
	$delete_posts = "delete from notifications where notice_id = '$notice_id' ";
	$run_delete = mysqli_query($con, $delete_posts);
	
	if($run_delete){
		
		header("location:view_notifications.php");		
		}	
	}
	

if(isset($_GET['gallery_id'])){
	
	$gallery_id = $_GET['gallery_id'];

	
	//$delete_posts = "delete from gallery where gallery_id = '$gallery_id' ";
        $delete_posts = "update gallery set status='0' where gallery_id = '$gallery_id' "; 
	$run_delete = mysqli_query($con, $delete_posts);
	
	if($run_delete){
		
		header("location:view_gallery_category.php");		
		}	
	}
	
if(isset($_GET['st_id'])){
	
	$st_id = $_GET['st_id'];

	
	$delete_posts = "update std_registration set status='0' where st_id = '$st_id' ";
	$run_delete = mysqli_query($con, $delete_posts);
	
	if($run_delete){
		
		header("location:register_student.php");		
		}	
	}



if(isset($_GET['En_id'])){
	
	$En_id = $_GET['En_id'];

	
	$delete_posts = "update enrolment_master set Active='0' where En_id = '$En_id' ";
	$run_delete = mysqli_query($con, $delete_posts);
	
	if($run_delete){
		
		header("location:app_form.php");		
		}	
	}

?>



