<?php

//$con = mysqli_connect("localhost","root","","same"); 
 $con = mysqli_connect("localhost","webakm","webakm@12","webakm"); 

?>
