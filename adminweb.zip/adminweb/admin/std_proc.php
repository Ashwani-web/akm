<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

<?php
if(isset($_POST['st_submit'])){
$st_name = $_POST['st_name'];
$st_email = $_POST['st_email'];
$st_contact = $_POST['st_contact'];
$st_password = $_POST['st_password'];




//$image = $_FILES['image']['name'];
//$image_tmp1 = $_FILES['image']['tmp_name'];
//move_uploaded_file($image_tmp1, "gallery-images/$image");
//$insert_details = "insert into  gallery (g_name,image_name,post_date) values ('$g_name','$image',NOW())";
//$insert_details = "insert into  std_registration (st_name,st_email,st_contact,st_password,created_on) values ('$st_name','$st_email','$st_contact','$st_password',NOW())";

$sql = "SELECT st_email from std_registration where st_email='$st_email'  ";
	 $result = mysqli_query($con,$sql);
	 $rows = mysqli_fetch_array($result);
if($rows >0)
{
echo "<script>alert('Youe Email id Exist')</script>";
echo "<script>location.href='std_proc.php'</script>";
 return false;
}
$sql = "SELECT st_contact from std_registration where st_contact='$st_contact'  ";
  $result = mysqli_query($con,$sql);
  $rows = mysqli_fetch_array($result);
if($rows >0)
{
echo "<script>alert('Your Contact No Exist')</script>";
echo "<script>location.href='std_proc.php'</script>";
 return false;
}
$insert_details="CALL st_insert('$st_name','$st_email','$st_contact','$st_password','','')";
//$insert_details="CALL st_insert ($_POST['st_name'],$_POST['st_email'],$_POST['st_contact'],$_POST['st_password'],'','')";
$run_insert = mysqli_query($con, $insert_details);
if($run_insert){
//echo "<script>location.href='register_student.php'</script>";
}
else{
echo "<script>alert('Error!!')</script>";
}
}
?>


<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">User REgister </h3> 
     
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data">
  
        <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name"> Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" name="st_name" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Email <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text"  name="st_email" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Contact</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  class="form-control col-md-7 col-xs-12" type="text" name="st_contact">
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Password <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <input  class="date-picker form-control col-md-7 col-xs-12" name="st_password" required="required" type="pass">
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" type="button">Cancel</button>
			<button type="submit" name="st_submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>

 
         </form>


 
 

              
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

