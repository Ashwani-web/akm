<?php
include("db.php");

$filename = "student_registration.csv";
$fp = fopen('php://output', 'w');
$query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='new_igesame' AND TABLE_NAME='std_registration'";
$result = mysqli_query($con,$query);
while ($row = mysqli_fetch_row($result)) {
	//$header[] = $row[0];
$header = array("st_name"=>"Name", "st_email"=>"Email", "st_contact"=>"Contact", "created_on"=>"Date");
}
header('Content-type: application/csv');
header('Content-Disposition: attachment; filename='.$filename);
fputcsv($fp, $header);

$query = "SELECT st_name,st_email,st_contact,created_on FROM std_registration";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_row($result)) {
	fputcsv($fp, $row);
}
exit;
?>




