<div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col menu_fixed">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;background-color: #eee;">
              <a href="index.php" class="site_title"><!--img src="images/same.png" style="width:100px;margin-left:40px;"--><p style="color:#4cba9a;text-align:center;">WEBAKM</p></p></a>
            </div>

            <div class="clearfix"></div>
 

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                
                <ul class="nav side-menu">
                  <!--li><a><i class="fa fa-user"></i> Student <span class="fa fa-chevron-down"></span></a-->
                    <!--ul class="nav child_menu">
                      <li><a href="register_student.php">Register Student</a></li>
                      <li><a href="online_application.php">Application Form</a></li>
                      <li><a href="user_online_payment.php">Online Payment</a></li>
                      
                    </ul>
                  </li-->
                  <!--li><a><i class="fa fa-table aria-hidden="true""></i>Campaign Data<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="campaign_data.php">Campaign Data</a></li>
                     
                    </ul>
                  </li-->
                  
                  
                  <li><a><i class="fa fa-newspaper-o aria-hidden="true""></i>Resource<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <!--li><a href="view_blog.php">Blogs</a></li-->
                      <li><a href="view_portfolio.php">Portfolio</a></li>
                      <!--li><a href="view_notifications.php">Notifications</a></li-->
                      <li><a href="view_testimonial.php">Testimonials</a></li>
                      <li><a href="view_member.php">Member</a></li>
                    </ul>
                  </li>
                  <!--li><a><i class="fa fa-edit"></i>Gallery<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="view_gallery_category.php">Gallery Category</a></li>
                      <li><a href="view_gallery.php">Gallery</a></li>
                    </ul>
                  </li-->
                   
                </ul>
              </div>	
              

            </div>
            
          </div>
        </div>
 
      </div>
    </div>

    
 
   
