<?php
session_start(); 
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("member_login.php", "_self")</script>';
}
include("db.php");

?>
<head>
    <meta content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css"> 
    <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<!--<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="../css/owl.theme.css" rel="stylesheet" media="screen" />-->
	<link href="css/animate.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/hover.css" rel="stylesheet">
    <link href="../css/responsive.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" media="all" href="css/webslidemenu.css" />
    
	<!--<link href="//fonts.googleapis.com/css?family=Noto+Serif:400,400i,700,700i" rel="stylesheet">-->
	<!--<link href="//fonts.googleapis.com/css?family=PT+Serif:400,700" rel="stylesheet">-->
    
    <link href='http://fonts.googleapis.com/css?family=Monda:400,700' rel='stylesheet' type='text/css'>
    
    <link href="http://fonts.googleapis.com/css?family=Lora:700%7COpen+Sans:400" rel="stylesheet" property="stylesheet" type="text/css" media="all">
    
	<!-- js -->
	<script type="text/javascript" src="../js/jquery-2.1.4.min.js"></script>        
	<script type="text/javascript" src="../js/webslidemenu.js"></script>

<script type="text/javascript" src="../js/faq-tree.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-91452784-1', 'auto');
  ga('send', 'pageview');

</script>

</head>







<style>
     .vld{color:red;}
     </style> 

<script>
function myFunction() {
    window.print();
}
</script>


<body>
<section id="content1" class="no-padding">

			<div class="container">

				<div class="row no-margin">

					<div id="main" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 entry-content">

						<div class="profile-detail">

							<div class="header-title text-center">

                            	<img src="../images/same_logo.png" alt="IGESAME">

                                <h4>
                                    4th Floor, Plot No.25/3, Knowledge Park-III, Greater Noida, Uttar Pradesh-201306<br>
                                    Approved by Director General of Civil Aviation , Ministry Of Civil Aviation, Govt Of Indian

                                </h4>

							</div>
							                            </div>
<?php
         $order_id=$_GET['order_id'];
	 $view_posts = "select * from enrolment_master where order_id = '$order_id'";
	$run_posts = mysqli_query($con, $view_posts);
	while($row_posts = mysqli_fetch_array($run_posts)){
	?> 

                            <div class="row">
                                 <div class="col-xs-12">

									<div class="title-block mb40">

										<h4>Application Form</h4>

									</div>
<div id="main" class="col-xs-10" style="padding-left: 0px;padding-right: 0px;"><p class="list2">
1. Befoure paying the application fee, please make sure that you fulfil all eligibility criteria as per details in the prospectus/Website.<br>
2. The completed application form is to be sent to the admission incharge at the above address.
</p>
                                    </div>
                                    
                                    <div id="main" class="col-xs-2"><img src="../user-images/<?php echo $row_posts['profile_image']; ?>" class="media-object" style="height:80px;"><label>Upload Photo</label></div>
                                    
                                    
                                    
                                    

                                </div>

                                <div class="divider"></div>


							<div class="row">

								<div class="col-xs-12">

									<div class="form-horizontal form-label-left">

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														First Name  <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

														<div class="row">

															<div class="col-md-12">

					<input type="text" name="f_name" value="<?php echo $row_posts['f_name']; ?>" class="form-control">
                                                             <span class="vld" id="errorBox"></span>
															</div>

														</div>

														

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Middle Name <span class="required">*</span>

													</label>

												<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">
                                                <input type="text" name="m_name" value="<?php echo $row_posts['m_name']; ?>" class="form-control">
                                                  <span class="vld" id="errorBox1"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Last Name  <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

					<input type="text" name="l_name" value="<?php echo $row_posts['l_name']; ?>" class="form-control">
                                                <span class="vld" id="errorBox2"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">D.O.B.</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

					<input type="text" name="dob" value="<?php echo $row_posts['dob']; ?>" class="form-control">
                                                 <span class="vld" id="errorBox3"></span>
													</div>

												</div>

											</div>

										</div>

                                        <div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

								<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">
                                                                   Place of Birth <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

				<input type="text" name="name_of_place" value="<?php echo $row_posts['name_of_place']; ?>" class="form-control">
                                                                 <span class="vld" id="errorBox4"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

										<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Gender <span class="required">*</span>

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<label class="radio-inline">

									
<input type="radio" class="radio" name="gender" value="Male" <?php if($row_posts['gender']=="Male"){ echo "checked";}?>/>Male

														</label>

									<label class="radio-inline">

									
<input type="radio" class="radio" name="gender" value="Female" <?php if($row_posts['gender']=="Female"){ echo "checked";}?>/>Female

									</label>
									
									<label class="radio-inline"><span class="vld" id="errorBox5"></span></label>
                                                                                           
													</div>

												</div>

											</div>
                                                                        
										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

					<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">Marital Status
                                        <span class="required">*</span>
                                        </label>

						<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

						<label class="radio-inline">
                         <input type="radio" class="radio" name="marital_status" value="Married" <?php if($row_posts['marital_status']=="Married"){ echo "checked";}?>/>Married

             </label>
              <label class="radio-inline">
            
<input type="radio" class="radio" name="marital_status" value="UnMarried" <?php if($row_posts['marital_status']=="UnMarried"){ echo "checked";}?>/>UnMarried
              </label>
              <label class="radio-inline"><span class="vld" id="errorBox6"></span></label>
                </div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

			<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">Address  <span class="required">*</span>

													</label>

								<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

					<textarea rows="1" name="address" class="form-control"><?php echo $row_posts['address']; ?></textarea>
                                                               <span class="vld" id="errorBox7"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

			<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">City <span class="required">*</span></label>

				<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

		<input type="text" name="city"  value="<?php echo $row_posts['city']; ?>" class="form-control">
                                  <span class="vld" id="errorBox8"></span>
				</div>
                              </div>

			</div>

        <div class="col-xs-12 col-md-6 col-lg-6">

				<div class="row">

				<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">State <span class="required">*</span>
                                   </label>

				<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">
<select name="state_a" class="form-control">
<option>Choose State</option>
<option <?php if ($row_posts['state_a'] == "Andra Pradesh") echo 'selected'; ?> value="Andra Pradesh">Andra Pradesh</option>

<option <?php if ($row_posts['state_a']== "Assam") echo 'selected'; ?>  value="Assam">Assam</option>
<option <?php if ($row_posts['state_a']== "Bihar") echo 'selected'; ?>  value="Bihar">Bihar</option>
<option <?php if ($row_posts['state_a']== "Chhattisgarh") echo 'selected'; ?>  value="Chhattisgarh">Chhattisgarh</option>
<option <?php if ($row_posts['state_a']== "Goa") echo 'selected'; ?>  value="Goa">Goa</option>

<option <?php if ($row_posts['state_a']== "Gujarat") echo 'selected'; ?>  value="Gujarat">Gujarat</option>
<option <?php if ($row_posts['state_a']== "Haryana") echo 'selected'; ?>  value="Haryana">Haryana</option>
<option <?php if ($row_posts['state_a']== "Himachal Pradesh") echo 'selected'; ?>  value="Himachal Pradesh">Himachal Pradesh</option>
<option <?php if ($row_posts['state_a']== "Jammu and Kashmir") echo 'selected'; ?>  value="Jammu and Kashmir">Jammu and Kashmir</option>
<option <?php if ($row_posts['state_a']== "Jharkhand") echo 'selected'; ?>  value="Jharkhand">Jharkhand</option>

<option <?php if ($row_posts['state_a']== "Karnataka") echo 'selected'; ?>  value="Karnataka">Karnataka</option>
<option <?php if ($row_posts['state_a']== "Kerala") echo 'selected'; ?>  value="Kerala">Kerala</option>
<option <?php if ($row_posts['state_a']== "Madya Pradesh") echo 'selected'; ?>  value="Madya Pradesh">Madya Pradesh</option>
<option <?php if ($row_posts['state_a']== "Maharashtra") echo 'selected'; ?>  value="Maharashtra">Maharashtra</option>
<option <?php if ($row_posts['state_a']== "Manipur") echo 'selected'; ?>  value="Manipur">Manipur</option>


<option <?php if ($row_posts['state_a']== "Meghalaya") echo 'selected'; ?>  value="Meghalaya">Meghalaya</option>
<option <?php if ($row_posts['state_a']== "Mizoram") echo 'selected'; ?>  value="Mizoram">Mizoram</option>
<option <?php if ($row_posts['state_a']== "Nagaland") echo 'selected'; ?>  value="Nagaland">Nagaland</option>
<option <?php if ($row_posts['state_a']== "Orissa") echo 'selected'; ?>  value="Orissa">Orissa</option>
<option <?php if ($row_posts['state_a']== "Rajasthan") echo 'selected'; ?>  value="Rajasthan">Rajasthan</option>

<option <?php if ($row_posts['state_a']== "Sikkim") echo 'selected'; ?>  value="Sikkim">Sikkim</option>
<option <?php if ($row_posts['state_a']== "Tamil Nadu") echo 'selected'; ?>  value="Tamil Nadu">Tamil Nadu</option>
<option <?php if ($row_posts['state_a']== "Tripura") echo 'selected'; ?>  value="Tripura">Tripura</option>
<option <?php if ($row_posts['state_a']== "Uttaranchal") echo 'selected'; ?> value="Uttaranchal">Uttaranchal</option>
<option <?php if ($row_posts['state_a']== "Uttar Pradesh") echo 'selected'; ?> value="Uttar Pradesh">Uttar Pradesh</option>

<option <?php if ($row_posts['state_a']== "West Bengal") echo 'selected'; ?>  value="West Bengal">West Bengal</option>
<option <?php if ($row_posts['state_a']== "Andaman and Nicobar") echo 'selected'; ?>  value="Andaman and Nicobar">Andaman and Nicobar</option>
<option <?php if ($row_posts['state_a']== "Chandigarh") echo 'selected'; ?>  value="Chandigarh">Chandigarh</option>
<option <?php if ($row_posts['state_a']== "Dadar and Nagar Haveli") echo 'selected'; ?>  value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option <?php if ($row_posts['state_a']== "Daman and Diu") echo 'selected'; ?>  value="Daman and Diu">Daman and Diu</option>

<option <?php if ($row_posts['state_a']== "Delhi") echo 'selected'; ?>  value="Delhi">Delhi</option>
<option <?php if ($row_posts['state_a']== "Lakshadeep") echo 'selected'; ?>  value="Lakshadeep">Lakshadeep</option>
<option <?php if ($row_posts['state_a']== "Pondicherry") echo 'selected'; ?>  value="Pondicherry">Pondicherry</option>
 


</select>
														
														 

														<span class="arrow"><i class="fa fa-sort"></i></span>

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Pin Code <span class="required">*</span>

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="zip" value="<?php echo $row_posts['zip']; ?>" class="form-control">
									

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

										Phone/Mobile No. <span class="required">*</span>

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="mobile_no" value="<?php echo $row_posts['mobile_no']; ?>" class="form-control" maxlength="10">
                                                                    
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Your Email <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

			<input type="text" name="your_email" value="<?php echo $row_posts['your_email']; ?>" class="form-control">
                                                                      
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Citizen Of India <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

										<label class="radio-inline">

			
<input type="radio" class="radio" name="citizen_of_india" value="Yes" <?php if($row_posts['citizen_of_india']=="Yes"){ echo "checked";}?>/>Yes

										</label>

							<label class="radio-inline">

						
<input type="radio" class="radio" name="citizen_of_india" value="No" <?php if($row_posts['citizen_of_india']=="No"){ echo "checked";}?>/>No
                                                       </label>
                                                       <label class="radio-inline"> <span class="vld" id="errorBox12"></span></label>
													</div>

												</div>

											</div>

										</div>

                                        <div class="divider"></div>

                                        <div class="form-group row">

											<div class="col-xs-12 col-md-12 col-lg-11">

												<div class="row">

									<label class="control-label col-lg-8 col-md-8 col-sm-8 col-xs-12">

		Educational Qualification of student: [10+2]or equivalent Passed [10+2]or equivalent appeared If [10+2]or equivalent appeared,then mention likely date of result
                                                                            </label>

											<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

				<input type="text" name="date_of_result" value="<?php echo $row_posts['date_of_result']; ?>" class="form-control">

													</div>

												</div>

											</div>

										</div>

                                        <div class="form-group row">

                                        	<div class="col-xs-12">

                                            	<div class="cart">

											<table class="data-table table-striped">

														<thead>

															<tr>

											<th class="column-title">Name of Examination Passed</th>

											<th class="column-title">Year Passing</th>

											<th class="column-title">Board/University</th>

										         <th class="column-title">% of Marks</th>

															</tr>

														</thead>

														<tbody>

															<tr>

						<td data-title="Name of Examination Passed" class="a-center">

						<input type="text" value="<?php echo $row_posts['name_of_examination']; ?>" name="name_of_examination" class="form-control" placeholder="Graduation">
                                                     </td>

						<td data-title="Year Passing" class="a-left">

					      <input type="text" value="<?php echo $row_posts['year_passing']; ?>" name="year_passing" class="form-control">

						</td>

					<td data-title="Board/University" class="a-left">

					<input type="text" value="<?php echo $row_posts['board_university']; ?>" name="board_university" class="form-control">

					</td>

				        <td data-title="% of Marks" class="a-left">

					<input type="text" value="<?php echo $row_posts['of_marks']; ?>" name="of_marks" class="form-control">

				         </td>

					</tr>

				     <tr>

					<td data-title="Name of Examination Passed" class="a-center">

		                 <input type="text"  name="name_of_examination_12" value="<?php echo $row_posts['name_of_examination_12']; ?>" class="form-control" placeholder="12th">

				</td>

				<td data-title="Year Passing" class="a-left">

				<input type="text" value="<?php echo $row_posts['year_passing_12']; ?>" name="year_passing_12" class="form-control">

			         </td>

				<td data-title="Board/University" class="a-left">

				<input type="text" value="<?php echo $row_posts['board_university_12']; ?>" name="board_university_12" class="form-control">

				</td>

				<td data-title="% of Marks" class="a-left">

			        <input type="text" value="<?php echo $row_posts['of_marks_12']; ?>" name="of_marks_12" class="form-control">

				</td>

															</tr>

															<tr>

				<td data-title="Name of Examination Passed" class="a-center">

			 <input type="text" value="<?php echo $row_posts['name_of_examination_10']; ?>" name="name_of_examination_10" class="form-control" placeholder="10th">

				</td>

				<td data-title="Year Passing" class="a-left">

				<input type="text" value="<?php echo $row_posts['year_passing_10']; ?>" name="year_passing_10" class="form-control">

				</td>

				<td data-title="Board/University" class="a-left">

				<input type="text" value="<?php echo $row_posts['board_university_10']; ?>" name="board_university_10" class="form-control">

				</td>

				<td data-title="% of Marks" class="a-left">

				<input type="text" value="<?php echo $row_posts['of_marks_10']; ?>" name="of_marks_10" class="form-control">

																</td>

															</tr>

															

														</tbody>

													</table>

												</div>

											</div>

										</div>

										<div class="divider"></div>

									</div>

									

									<div class="form-horizontal form-label-left">

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

								<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Stream applied for <span class="required">*</span>

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

											<label class="radio-inline">

							
 <input type="radio" class="radio" name="stream_applied" value="Mechanical" <?php if($row_posts['stream_applied']=="Mechanical"){ echo "checked";}?>/>Mechanical
                                                                         </label>

								<label class="radio-inline">

						
<input type="radio" class="radio" name="stream_applied" value="Avionics" <?php if($row_posts['stream_applied']=="Avionics"){ echo "checked";}?>/>Avionics
                                                                        </label>
                                                  <span class="vld" id="errorBox13"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

						<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

										Non-Refundable Application fees Rs.1000/-

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="amount" value="<?php echo $row_posts['amount']; ?>" class="form-control">

													</div>

												</div>

											</div>

										</div>

										

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Payment Details <span class="required">*</span>

														

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

													<label class="radio-inline">


<input type="radio" class="radio" id="noCheck" onclick="javascript:yesnoCheck();" name="payment_details" value="Online" <?php if($row_posts['payment_details']=="Online"){echo "checked";}?>/>Online

														</label>

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Name of Parent/ Guardian

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<input type="text" name="gurdian_name" value="<?php echo $row_posts['gurdian_name']; ?>" class="form-control">

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Phone/Mobile No. <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="phone_no" value="<?php echo $row_posts['phone_no']; ?>" class="form-control">

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Your Email <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

										<input type="text" name="parent_email" value="<?php echo $row_posts['parent_email']; ?>" class="form-control">

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Address  <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

						<textarea rows="1" name="parent_address" class="form-control"><?php echo $row_posts['parent_address']; ?></textarea>

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Occupations

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

							<input type="text" name="parent_occupations" value="<?php echo $row_posts['parent_occupations']; ?>" class="form-control">

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Annual Income

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

							<input type="text" name="parent_annualincome" value="<?php echo $row_posts['parent_annualincome']; ?>" class="form-control">

													</div>

												</div>

											</div>

										</div>

										

										

										<div class="form-group row">

											<div class="col-xs-12 col-md-12 col-lg-12">

												<div class="row">

											<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

												<label class="radio-inline">

			

<input type="radio" name="i_hereby" value="yes" <?php if($row_posts['i_hereby']=="yes"){ echo "checked";}?>/>			I hereby declare that the above information is complete and true to the best of my knowledge.	

														</label>

													</div>

												</div>

											</div>

										</div>

										

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Date

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<input type="text" name="date_final" value="<?php echo $row_posts['date_final']; ?>" class="form-control">

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

										<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Place

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

				<input type="text" name="place_final" value="<?php echo $row_posts['place_final']; ?>" class="form-control">

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Signature

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

		<input type="text" name="applicant_signature" value="<?php echo $row_posts['applicant_signature']; ?>" class="form-control">

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Your Message

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">
 
		 <textarea rows="3" name="your_message"  class="form-control"><?php echo $row_posts['your_message']; ?></textarea>
						

													</div>

												</div>

											</div>

										</div>

										

										<hr class="full-width">

									</div>

									 </div>

								<div class="col-xs-12 col-md-12">

									<div class="buttons-set">

<button class="btn btn-primary" style="background-color:#90bc3d;width:115px;border-radius:0px;border-color:#fff;margin-bottom:30px;" onclick="myFunction()">Print</button>

									</div>

								</div>

							</div><?php } ?> 

						</div>

					</div>

				</div>

			</div>

		</section>
      <?php include("footer.php");?>	

		 </body>

	

