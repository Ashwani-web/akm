<?php
include("db.php");

$filename = "campaign_data.csv";
$fp = fopen('php://output', 'w');
$query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='new_igesame' AND TABLE_NAME='campaign_data'";
$result = mysqli_query($con,$query);
while ($row = mysqli_fetch_row($result)) {
	//$header[] = $row[0];
$header = array("name"=>"Name", "email_id"=>"Email", "contact_no"=>"Contact", "	state"=>"State" , "city"=>"City", "course"=>"Course");
}
header('Content-type: application/csv');
header('Content-Disposition: attachment; filename='.$filename);
fputcsv($fp, $header);

$query = "SELECT name,email_id,contact_no,state,city,course FROM campaign_data";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_row($result)) {
	fputcsv($fp, $row);
}
exit;
?>




