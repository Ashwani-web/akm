
<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

<?php
$cookie_name = "user";
$cookie_value = "John Doe";

$f_name =  "f_name";	
$m_name =  "m_name";
$l_name =  "l_name";







setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
?>


<?php
if(!isset($_COOKIE[$cookie_name])) {
     echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
     echo "Cookie '" . $cookie_name . "' is set!<br>";
     echo "Value is: " . $_COOKIE[$cookie_name];
}
?>

<?php 

if(isset($_POST['enroll_submit'])){
$image = $_FILES['image']['name'];
$image_tmp1 = $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp1, "user-images/$image");
//$profile_image = $_POST['profile_image'];
$f_name = $_POST['f_name'];	
$m_name = $_POST['m_name'];
$l_name = $_POST['l_name'];
$dob = $_POST['dob'];
$name_of_place = $_POST['name_of_place'];
$gender = $_POST['gender'];
$marital_status = $_POST['marital_status'];
$address = $_POST['address'];
$city = $_POST['city'];

$insert_details = "insert into  enrolment_master (profile_image,f_name,m_name,l_name,dob,name_of_place,gender,marital_status,address,city,status) 
values ('$image','$f_name','$m_name','$l_name','$dob','$name_of_place','$gender','$marital_status','$address','$city','$status') ";

 
//$insert_details="CALL st_insert('$st_name','$st_email','$st_contact','$st_password','','')";

$run_insert = mysqli_query($con, $insert_details);
if($run_insert){
//echo "<script>location.href='enroll.php'</script>";
}
else{
echo "<script>alert('Error!!')</script>";
}
}








?>

<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Student Register </h3> 
     
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data" name="myform" action="http://www.javatpoint.com/javascriptpages/valid.jsp" onsubmit="return validate()">
  
 <input type="file" name="image"  placeholder="Profile image" value="">
 <input type="text" class="form-control" name="f_name"   placeholder="First name" value="" required="">
 <input type="text" class="form-control" name="m_name"   placeholder="Middle name" value="">
  <input type="text" class="form-control" name="l_name" placeholder="Last name" value="">
  <input type="text" class="form-control" name="dob"  placeholder="DOB" value="">
  <input type="text" class="form-control" name="name_of_place" placeholder="Place" value="" required="">
  <label class="radio-inline"> <input type="radio" name="gender" value="male" checked="">Male</label>
  <label class="radio-inline"> <input type="radio" name="gender" value="female">Female</label>
   
   <label class="radio-inline"><input type="radio" name="marital_status" value="Married" checked="">Married</label>
   <label class="radio-inline"><input type="radio" name="marital_status" value="Un-married">Un-married</label>
   <input type="text" name="address"   class="form-control" placeholder="Address" value="">
   <input type="text" name="city"   class="form-control" placeholder="city" value="" required="">
    
<input type="submit" name="enroll_submit" style="margin-top:2%;" class="btn " value="Submit Now"></div>

 
         </form>


 
 

              
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>



