<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             
 
  <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <h3 style="text-align: center; padding: 15px; background-color: #2b4055; color: #fff;">Testimonial<a href="testimonial.php" class="btn btn-success pull-right">Add Testimonial</a></h3> 
                  <div class="x_content">
                    
                    <table id="datatable" class="table table-striped table-bordered mytable">
                      <thead>
                        <tr>
                          <th>Sn.</th>
                          <th>Testimonial Name</th>
                          <th>Testimonial Position</th>
                          <th>Testimonial Image</th>
                          <th>Testimonial Content</th>
                           <th>Date</th>
                          <th>Action</th>
                          </tr>
                      </thead>


                      <tbody>
                           <?php 
                                $i=1;
                                $view_posts = "select * from  testimonials   ";
				 $run_posts = mysqli_query($con, $view_posts);
				 while($row_posts = mysqli_fetch_array($run_posts))
{
			   ?>
                        <tr>
                          <td><?php echo $i++ ?></td>
                          <td><?php echo $row_posts['testimonial_u_name']; ?></td>
                          <td><?php echo $row_posts['t_position']; ?></td>
                          
                          <td> <img src="testimonial/<?php echo $row_posts['testimonial_img']; ?>" style="width:120px;text-align:center;"></td>
                          <td><?php echo $row_posts['testimonial_content']; ?></td>
                          <td><?php echo $row_posts['post_date']; ?></td>
                          <td>
                           <a href="edit_testimonial.php?testimonial_id=<?php echo $row_posts['testimonial_id']; ?>"><img src="images/edit.png"></a>
                           &nbsp;
                            <a href="delete.php?testimonial_id=<?php echo $row_posts['testimonial_id']; ?>" onclick="return confirm('Are you sure, you want to delete ??');"><img src="images/delete.png"></a>
                        </td>
                       </tr>

 
                        
                        <?php } ?>
                        
                         
                      </tbody>
                    </table>
 
                    </form>
 
                  </div>
                </div>
              </div>
 
              </div>
  
            </div>
          </div>
        </div>
         <?php include("footer.php");?>
<style>
.mytable tbody tr td{
  max-width:240px; /* Customise it accordingly */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}


</style>
