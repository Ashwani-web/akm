<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>
<style>
.fixed_wt{width: 130px;
    font-size: 15px;}
.fixed_wt1{
    width: 170px;
    font-size: 15px;
}
.fixed_wt4{
    
    font-size: 15px;
}
.fixed_wt2{
    width: 200px;
    font-size: 15px;
}

</style>
     

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
             <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
<h3 style="text-align: center; padding: 12px; background-color: #2b4055; color: #fff;">Online Payment<a href="app_csv.php" class="btn btn-success pull-right">Download csv</a></h3>
                  <div class="x_content">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th><p>Sn.</p></th>
                          
                          <th><p>Name</p></th>
                          <th><p class="fixed_wt">Email</p></th>
                          <th><p>Contact</p></th>
                          <th><p>Payment Status</p></th>
                           <th><p>Amount</p></th>
                           <th><p>Download</p></th>
                            <th><p class="fixed_wt">Date</p></th>
                          <th><p class="fixed_wt4" >Image</p></th>
                         
                        
                            
                        </tr>
                      </thead>
                      <tbody>
                          <?php 
                                $i=1;
                             
                                //$id=$_GET['order_id'];	
                                //$view_posts = "select * from  enrolment_master  where Active='1'  ";
                                
                                
                 $view_posts = "select order_id,profile_image,f_name,your_email,mobile_no,payment_details,created_on,gender,marital_status,address,city,state_a,zip, stream_applied,amount,payment_details,gurdian_name,phone_no,parent_email,parent_address,parent_occupations, date_final,applicant_signature,your_message,created_on,CASE WHEN STATUS='1' THEN 'Success' WHEN STATUS='2' THEN  'Failure' WHEN STATUS='0' THEN  'Pending' ELSE STATUS  END AS Status  from  enrolment_master  where Active='1' ORDER BY order_id DESC  ";               
                                
                                $run_posts = mysqli_query($con, $view_posts);
				 while($row_posts = mysqli_fetch_array($run_posts)) {
                            ?>
                        <tr>
                          <td><?php echo $i++ ?></td>
                          
                          <td><?php echo $row_posts['f_name']; ?></td>
                          <td><?php echo $row_posts['your_email']; ?></td>
                          <td><?php echo $row_posts['mobile_no']; ?></td>
                          
                          <td style="color:green;"><?php echo $row_posts['Status']; ?></td>
                          <td><?php echo $row_posts['amount']; ?></td>
                          <td style="color:green;"><a href="download_form.php?order_id=<?php echo $row_posts['order_id']; ?>" target="_blank" >Download</a></td>
                         
                          <td><?php echo $row_posts['created_on']; ?></td>
                          <td><img style="width: 75px;height: 60px;;" src="../user-images/<?php echo $row_posts['profile_image']; ?>"></td>

                         
                          
                           
                        </tr> 
                       <?php } ?> 
                     </tbody>
                    </table> 
                  </form> 
 
 
 

                  </div>
                </div>
              </div>
             </div>
            </div>
          </div>
        </div>
         <?php include("footer.php");?>
