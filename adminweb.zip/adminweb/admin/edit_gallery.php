<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
$gallery_id=$_GET['gallery_id'];
?>
<?php
if(isset($_POST['gallery_update'])){
$g_name = $_POST['g_name'];
$image = $_FILES['image']['name'];
$image_tmp1 = $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp1, "gallery-images/$image");

 $update_query = "update gallery set g_name = '$g_name',image_name='$image',post_date= NOW() where gallery_id = '$gallery_id' ";
$update_run = mysqli_query($con, $update_query);
if($update_run)
{
//$msg = '<div class="alert alert-success">Successfully Updated !</div>';
header("location:view_gallery.php"); 
}
else {
echo mysqli_error($con);
}
}
 

?>
 <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Update Gallery </h3> 
   <br/>                    
   <br/> 
   <br/>   
 <?php
         //$news_id=$_GET['news_id'];
	 $view_posts = "select * from gallery where gallery_id = '$gallery_id'";
	$run_posts = mysqli_query($con, $view_posts);
	while($row_posts = mysqli_fetch_array($run_posts)){
	?> 
 
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data" >
<br/>   
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" ">Gallery Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text" id="first-name" name="g_name" value="<?php echo $row_posts['g_name']; ?>" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

      <div class="form-group">
                 <label class="control-label col-md-3 col-sm-3 col-xs-12" ></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <img src="gallery-images/<?php echo $row_posts['image_name']; ?>" style="width:300px;">
                        </div>
                      </div>

                  <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" >Gallery Image <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="file"  name="image" required="required" >                      
                        </div>
                    </div>

  <br/>   
<br/>     
                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <a href="view_gallery_category.php" class="btn btn-primary">Cancel</a>
			  <button type="submit" class="btn btn-success" name="gallery_update">Update</button>
                        </div>
                      </div>
<br/>  
<br/>  
<br/> 
                    </form> <?php } ?> 
<br/>  
<br/>  
<br/>                 
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

