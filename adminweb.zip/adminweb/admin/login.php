<?php
session_start();
include("db.php");
if(isset($_POST['admin_submit'])){

	$admin_name = $_POST['admin_name'];
	$admin_password = $_POST['admin_pass'];
	
	$login_query = "select * from admin_login where user_name = '$admin_name' AND password = '$admin_password' ";
	
	$run = mysqli_query($con, $login_query);
	
	if(mysqli_num_rows($run)>0){
		
	$row = mysqli_fetch_array($run);
	
	 $_SESSION['id_admin'] = $row['id'];
	 $_SESSION['name_admin'] = $row['user_name'];
	
	header("location: index.php");

}
else
{
echo "<script>alert('User Name or Password is Incorrect !')</script>";
}

}

?>
<script type="text/javascript">
        function validate_form() {
            if (document.adm.admin_name.value == "") {
                document.getElementById("errorBox").innerHTML = "Enter Your User Name";
                return false;
            }
            if (document.adm.admin_pass.value == "") {
               // alert("Enter 'Your Middle Name'");
                document.getElementById("errorBox1").innerHTML = "Enter Your Password";
                return false;
            }
              
        }
    </script>
 
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Webakm</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>
<style>
.ad{margin-bottom:0px!important;
   margin-top:10px!important;}
.vld{color:red;}
</style>
  <body class="login" /*style="background: url(images/admin.jpg) no-repeat center center fixed;background-size: cover;"*/>
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form" style="background-color: #fff;padding: 40px;">
          <section class="login_content" style="padding:0px;">
<!--img src="images/same.png"-->
            <form role="form" method="post" enctype="multipart/form-data" name="adm" action="" onsubmit ="return validate_form();">
  
              <h1>Admin Login</h1>
              <div>
                <input type="text" name="admin_name" class="form-control ad" placeholder="Username"/><span class="vld" id="errorBox"></span>
              </div>
              <div>
                <input type="password" name="admin_pass" class="form-control ad" placeholder="Password"/><span class="vld" id="errorBox1"></span>
              </div>
              <div>
                 
 <input type="submit"  class="btn btn-primary ad" value="Login" name="admin_submit">
           
          
                <a class="reset_pass" href="#">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <div class="clearfix"></div>
                <br />
              <div>
                  <p>Copyright © 2019</p>
                </div>
              </div>
            </form>
          </section>
        </div>

        
      </div>
    </div>
  
