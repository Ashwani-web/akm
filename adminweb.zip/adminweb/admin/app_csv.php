<?php
include("db.php");

$filename = "online_application.csv";
$fp = fopen('php://output', 'w');

$query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='new_igesame' AND TABLE_NAME='enrolment_master'";
$result = mysqli_query($con,$query);
while ($row = mysqli_fetch_row($result)) {
	//$header[] = $row[0];
$header = array("profile_image"=>"Image Name", "f_name"=>"First Name", "m_name"=>"Middle Name", "l_name"=>"Last Name","dob"=>"DOB",

 "name_of_place"=>"Name Of Place", "gender"=>"Gender", "marital_status"=>"Marital Status","address"=>"Address", "city"=>"City", "state_a"=>"State",

 "zip"=>"Zip Code","mobile_no"=>"Mobile No", "your_email"=>"Email", "citizen_of_india"=>"Citizen of India", "date_of_result"=>"Result Date","name_of_examination"=>"Examination Name",

"year_passing"=>"Passing Year", "board_universit"=>"Board/Universit", "of_marks"=>"Marks","name_of_examination_12"=>"Examination Name", "	year_passing_12"=>"Passing Year 12th", "board_university_12"=>"Board/Universit",

 "of_marks_12"=>"Marks 12th","name_of_examination_10"=>"Examination Name", "year_passing_10"=>"Passing Year 10th", "board_university_10"=>"Board/Universit ", "of_marks_10"=>"Marks 10th","stream_applied"=>"Stream Applied",

 "amount"=>"Fee", "payment_details"=>"Payment Details", 
 "gurdian_name"=>"Gurdian Name","phone_no"=>"Contact No", "parent_email"=>"Parent Email", "parent_address"=>"Parent Address", "parent_occupations"=>"Parent Occupations","parent_annualincome"=>"Parent Annual Income",

 "i_hereby"=>"Decleration", "date_final"=>"Date", "place_final"=>"Applicatnt Place","applicant_signature"=>"Signature", "your_message"=>"Message", "created_on"=>"Submission Date "

);

}	

header('Content-type: application/csv');
header('Content-Disposition: attachment; filename='.$filename);
fputcsv($fp, $header);

$query = "SELECT 	profile_image,f_name,m_name,l_name,dob,name_of_place,gender,marital_status,address,city,state_a,zip,mobile_no,
your_email,citizen_of_india,date_of_result,name_of_examination,year_passing,board_university,of_marks,name_of_examination_12,year_passing_12,
board_university_12,of_marks_12,name_of_examination_10,year_passing_10,board_university_10,of_marks_10,	stream_applied,amount, payment_details,
gurdian_name,phone_no,parent_email,parent_address,parent_occupations,parent_annualincome,date_final,
place_final,i_hereby,applicant_signature,your_message,created_on

FROM enrolment_master";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_row($result)) {
	fputcsv($fp, $row);
}
exit;
?>
