<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>

 








<?php
//if(isset($_POST['enroll_submit'])){

//$f_name = $_POST['f_name'];	
//$m_name = $_POST['m_name'];
//$l_name = $_POST['l_name'];
 
 if (isset($_POST['enroll_submit']) && !empty($_POST['enroll_submit'])){

$varf_name = $_POST['f_name'];
$varm_name = $_POST['m_name'];
$varl_name = $_POST['l_name'];
$errorMessage = "";


if(empty($varf_name)) {
$errorMessage .="<li>Ficken! Ohne Dich!</li>";
}
if(empty($varm_name)) {
$errorMessage .="<li>m name</li>";
}
if(empty($varl_name)) {
$errorMessage .="<li>L name</li>";
}
if($errorMessage == ""){
//save to db here 


$insert_details = "insert into  enrolment_master (varf_name,varm_name,varl_name) 
values ($_POST['f_name'],$_POST['m_name'],$_POST['l_name'] ) ";
$run_insert = mysqli_query($con, $insert_details);
if($run_insert){
//echo "<script>location.href='enroll.php'</script>";
}

 

}
else {

 
//show error here 
echo "<ul>".$errorMessage."</ul>";
}

}


 



//$insert_details = "insert into  enrolment_master (f_name,m_name,l_name, ) 
//values ('$f_name','$m_name','$l_name'  ";
//$run_insert = mysqli_query($con, $insert_details);
//if($run_insert){
//echo "<script>location.href='enroll.php'</script>";
//}
//else{
//echo "<script>alert('Error!!')</script>";
//}
//}
?>


<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Student Register </h3> 
     
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data"  >
  
 
 <input type="text" class="form-control" name="f_name"   placeholder="First name" value="" >
 <input type="text" class="form-control" name="m_name"   placeholder="Middle name" value="">
<input type="text" class="form-control" name="l_name"   placeholder="Middle name" value="">
   
<input type="submit" name="enroll_submit" style="margin-top:2%;" class="btn " value="Submit Now"></div>

</form>


 
 

              
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

