<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
$st_id=$_GET['st_id'];
?>
<?php
if(isset($_POST['register_update'])){
$st_name = $_POST['st_name'];
$st_email = $_POST['st_email'];

$st_contact = $_POST['st_contact'];



 $update_query = "update std_registration set st_name = '$st_name', st_email = '$st_email',st_contact='$st_contact',post_date= NOW() where st_id = '$st_id' ";
$update_run = mysqli_query($con, $update_query);
if($update_run)
{
//$msg = '<div class="alert alert-success">Successfully Updated !</div>';
header("location:register_student.php"); 
}
else {
echo mysqli_error($con);
}
}
 

?>
 


 <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Update Notifications </h3> 
   <br/>                    
   <br/> 
   <br/>   
 <?php
         //$news_id=$_GET['news_id'];
	 $view_posts = "select * from std_registration where st_id = '$st_id'";
	$run_posts = mysqli_query($con, $view_posts);
	while($row_posts = mysqli_fetch_array($run_posts)){
	?> 
 
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data" >
<br/>   
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Student Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text" id="first-name" name="st_name" value="<?php echo $row_posts['st_name']; ?>" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
    
  <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Student Contact<span class="required">*</span></label>
                     <div class="col-md-6 col-sm-6 col-xs-12"><input type="text" id="blog_content" name="st_email" value="<?php echo $row_posts['st_contact']; ?>" class="form-control col-md-7 col-xs-12">
   </div>
   </div>
      
  <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Student Email<span class="required">*</span></label>
                     <div class="col-md-6 col-sm-6 col-xs-12"><input type="text" id="blog_content" name="st_email" value="<?php echo $row_posts['st_email']; ?>" class="form-control col-md-7 col-xs-12">
 
                        </div>
                      </div>
                      
                    <br/>   
<br/>     
                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <a href="view_notifications.php" class="btn btn-primary">Cancel</a>
			  <button type="submit" class="btn btn-success" name="register_update">Update</button>
                        </div>
                      </div>
<br/>  
<br/>  
<br/> 
                    </form> <?php } ?> 
<br/>  
<br/>  
<br/>                 
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

