<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
?>
<style>
.fixed_wt{width: 130px;
    font-size: 15px;}
.fixed_wt1{
    width: 170px;
    font-size: 15px;
}
.fixed_wt4{
    
    font-size: 15px;
}
.fixed_wt2{
    width: 200px;
    font-size: 15px;
}

</style>
     

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
             <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
<h3 style="text-align: center; padding: 12px; background-color: #2b4055; color: #fff;">Online Application<a href="app_csv.php" class="btn btn-success pull-right">Download csv</a></h3>
                  <div class="x_content">
                   <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th><p>Sn.</p></th>
                          <th><p class="fixed_wt4" >Image</p></th>
                          <th><p class="fixed_wt">Applicant Name</p></th>
                          <th><p class="fixed_wt">Applicant Email</p></th>
                          <th><p class="fixed_wt">Applicant Contact</p></th>
                           <th><p class="fixed_wt">Payment Mathod</p></th>
                           <th><p class="fixed_wt">Payment Status</p></th>
                            <th><p class="fixed_wt">Date</p></th>
                          <th><p class="fixed_wt">Name of Place</p></th>
                          <th><p class="fixed_wt">Gender</p></th>
                          <th><p class="fixed_wt">Marital Status</p></th>
                          <!--th>Applicant Contact</th-->
                           <th><p class="fixed_wt">Addres</p></th>
                           <th><p class="fixed_wt">City</p></th>
                           <th><p class="fixed_wt">State</p></th>
                          <th><p class="fixed_wt">Zip</p></th>
                          <th><p class="fixed_wt">Citizen</p></th>
                          <th><p class="fixed_wt">Date of Result</p></th>
                          <th><p class="fixed_wt1">Name of Examination</p></th>
                          <th><p class="fixed_wt">year Passing</p></th>
                          <th><p class="fixed_wt">Board University</p></th>
                          <th><p class="fixed_wt">Marks</p></th>
                          <th><p class="fixed_wt2">Name of Examination 12th</p></th>
                          <th><p class="fixed_wt1">Year of Passing 12th</p></th>
                          <th><p class="fixed_wt1">Board university 12th</p></th>
                          <th><p class="fixed_wt">Marks 12</p></th>
                          <th><p class="fixed_wt2">Name of Examination 10th</p></th>
                          <th><p class="fixed_wt1">Year Passing 10th</p></th>
                          <th><p class="fixed_wt1">Board university 10th</p></th>
                          <th><p class="fixed_wt">Marks 10th</p></th>
                          <th><p class="fixed_wt">Stream Applied</p></th>
                          <th><p class="fixed_wt">Amount</p></th>
                          <th><p class="fixed_wt">Payment Details</p></th>
                          <th><p class="fixed_wt">Paying by</p></th>
                          <th><p class="fixed_wt">DD date</p></th>
                          <th><p class="fixed_wt">Bank Name</p></th>
                          <th><p class="fixed_wt">Payable_at</p></th>
                          <th><p class="fixed_wt">Gurdian_name</p></th>
                          <th><p class="fixed_wt">parent Email</p></th>
                          <th><p class="fixed_wt">parent Address</p></th>
                          <th><p class="fixed_wt1">Parent Occupations</p></th>
                          <th><p class="fixed_wt1">Parent Annualincome</p></th>
                           <th><p class="fixed_wt">I here by</p></th>
                           <th>	<p class="fixed_wt1">Date of submission</p></th>	l
                           <th><p class="fixed_wt">Place fina</p></th>
                           <th><p class="fixed_wt1">Applicant Signature</p></th>
                           <th><p class="fixed_wt">Your Message</p></th>
                           <th><p class="fixed_wt">status</p></th>
                            <th><p class="fixed_wt">Date </p></th>
                            <th><p class="fixed_wt4">Action</p></th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php 
                                $i=1;
                                $view_posts = "select * from  enrolment_master where Active='1'  ";
				$run_posts = mysqli_query($con, $view_posts);
				 while($row_posts = mysqli_fetch_array($run_posts)) {
                            ?>
                        <tr>
                          <td><?php echo $i++ ?></td>
                          <td><img style="width: 75px;;" src="user-images/<?php echo $row_posts['profile_image']; ?>"></td>
                          <td><?php echo $row_posts['f_name']; ?></td>
                          <td><?php echo $row_posts['your_email']; ?></td>
                          <td><?php echo $row_posts['mobile_no']; ?></td>
                          <td><?php echo $row_posts['payment_details']; ?></td>
                          <td><?php echo $row_posts['status']; ?></td>
                          <td><?php echo $row_posts['created_on']; ?></td>


                          <td><?php echo $row_posts['name_of_place']; ?></td>
                          <td><?php echo $row_posts['gender']; ?></td>
                          <td><?php echo $row_posts['marital_status']; ?></td>
                          <td><?php echo $row_posts['address']; ?></td>
                          <td><?php echo $row_posts['city']; ?></td>
                          <td><?php echo $row_posts['state_a']; ?></td>
                          <td><?php echo $row_posts['zip']; ?></td>
                          <td><?php echo $row_posts['citizen_of_india']; ?></td>
                          <td><?php echo $row_posts['date_of_result']; ?></td>
                          <td><?php echo $row_posts['name_of_examination']; ?></td>
                          <td><?php echo $row_posts['year_passing']; ?></td>
                          <td><?php echo $row_posts['board_university']; ?></td>
                          <td><?php echo $row_posts['of_marks']; ?></td>
                          <td><?php echo $row_posts['name_of_examination_12']; ?></td>
                          <td><?php echo $row_posts['year_passing_12']; ?></td>
                          <td><?php echo $row_posts['board_university_12']; ?></td>



                          <td><?php echo $row_posts['of_marks_12']; ?></td>
                          <td><?php echo $row_posts['name_of_examination_10']; ?></td>
                          <td><?php echo $row_posts['year_passing_10']; ?></td>
                          <td><?php echo $row_posts['board_university_10']; ?></td>
                          <td><?php echo $row_posts['of_marks_10']; ?></td>
                          <td><?php echo $row_posts['stream_applied']; ?></td>
                          <td><?php echo $row_posts['amount']; ?></td>
                          <td><?php echo $row_posts['payment_details']; ?></td>
                          <td><?php echo $row_posts['paying_by']; ?></td>
                          <td><?php echo $row_posts['dd_date']; ?></td>
                          <td><?php echo $row_posts['bank_name']; ?></td>
                          <td><?php echo $row_posts['payable_at']; ?></td>
                          <td><?php echo $row_posts['gurdian_name']; ?></td>
                          <td><?php echo $row_posts['phone_no']; ?></td>
                          <td><?php echo $row_posts['parent_email']; ?></td>
                          <td><?php echo $row_posts['parent_address']; ?></td>

                          <td><?php echo $row_posts['parent_occupations']; ?></td>
                          <td><?php echo $row_posts['parent_annualincome']; ?></td>
                          <td><?php echo $row_posts['i_hereby']; ?></td>
                          <td><?php echo $row_posts['date_final']; ?></td>
                          <td><?php echo $row_posts['place_final']; ?></td>
                          <td><?php echo $row_posts['applicant_signature']; ?></td>
                          <td><?php echo $row_posts['your_message']; ?></td>
                          <td><?php echo $row_posts['created_on']; ?></td>
                           <td>
                      <a href="edit_notifications.php?notice_id=<?php echo $row_posts['	']; ?>"><img src="images/edit.png"></a>
                           &nbsp;
                      <a href="delete.php?En_id=<?php echo $row_posts['En_id']; ?>" onclick="return confirm('Are you sure you want to delete ??');"><img src="images/delete.png"></a>
  
                        </td> 
                        </tr> 
                       <?php } ?> 
                     </tbody>
                    </table> 
                  </form> 
 
 
 

                  </div>
                </div>
              </div>
             </div>
            </div>
          </div>
        </div>
         <?php include("footer.php");?>
