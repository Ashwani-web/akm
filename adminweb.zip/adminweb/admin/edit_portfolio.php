<?php 
session_start(); 
include("db.php");
if(isset($_SESSION['id_admin']) == ''){
echo '<script>window.open("login.php", "_self")</script>';
}
include("head.php");
$p_id=$_GET['p_id'];
?>
<?php
if(isset($_POST['portfolio_update'])){
$p_name = $_POST['p_name'];
$p_url = $_POST['p_url'];
$image = $_FILES['image']['name'];
$image_tmp1 = $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp1, "portfolio/$image");
  $update_query = "update portfolio set p_name = '$p_name', p_url = '$p_url', p_image='$image',post_date= NOW() where p_id = '$p_id' ";
$update_run = mysqli_query($con, $update_query);
if($update_run)
{
//$msg = '<div class="alert alert-success">Successfully Updated !</div>';
header("location:view_portfolio.php"); 
}
else {
echo mysqli_error($con);
}
}
 

?>
 


 <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <!-- menu profile quick info -->
             <?php include("sidebar.php");?>
            <!-- /menu profile quick info -->
 
          </div>
        </div>

        <!-- top navigation -->
          <?php include("header.php");?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
             

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
        
 <h3 style="text-align: center; padding: 10px; background-color: #2b4055; color: #fff;">Update Portfolio </h3> 
   <br/>                    
   <br/> 
   <br/>   
 <?php
         //$p_id=$_GET['p_id'];
	 $view_posts = "select * from portfolio where p_id =  '$p_id'";
	$run_posts = mysqli_query($con, $view_posts);
	while($row_posts = mysqli_fetch_array($run_posts)){
	?> 
 
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data" >
<br/>   
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Portfolio Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text" id="first-name" name="p_name" value="<?php echo $row_posts['p_name']; ?>" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


               <div class="form-group">
                 <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Image <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <img src="portfolio/<?php echo $row_posts['p_image']; ?>" style="width:300px;">
                        </div>
                      </div>

                  <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Portfolio Image <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="file"  name="image" required="required" >                      
                        </div>
                    </div>

 
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Portfolio Url <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                       <input type="text" id="last-name" name="p_url"  value="<?php echo $row_posts['p_url']; ?>" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      
                    <br/>   
<br/>     
                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <a href="view_portfolio.php" class="btn btn-primary">Cancel</a>
			  <button type="submit" class="btn btn-success" name="portfolio_update">Update</button>
                        </div>
                      </div>
<br/>  
<br/>  
<br/> 
                    </form> <?php } ?> 
<br/>  
<br/>  
<br/>                 
 </div>
</div>
          </div>
        </div>
<br/>  
         <?php include("footer.php");?>

