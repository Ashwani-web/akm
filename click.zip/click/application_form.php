<?php
session_start(); 
if(isset($_SESSION['user_name']) == ''){
echo '<script>window.open("member_login.php", "_self")</script>';
}
include("db.php");
include("head.php");
?>


<link rel="stylesheet" href="css/css/datepicker.css">
  <link rel="stylesheet" href="css/css/main.css">
<script type="text/javascript">
        
         function validateApp() {
            if (document.myform2.f_name.value == "") {
                document.getElementById("errorBox101").innerHTML = "Enter Your First Name";
                return false;
            }
            
           
            
            if (document.myform2.l_name.value == "") {
                document.getElementById("errorBox103").innerHTML = "Enter Your last name";
                return false;
            }
			
			
			if (document.myform2.dob.value == "") {
                document.getElementById("errorBox104").innerHTML = "Enter Your date of birth";
                return false;
            }
			
			if (document.myform2.name_of_place.value == "") {
                document.getElementById("errorBox105").innerHTML = "Enter Your place";
                return false;
            }
			
			
			
			if (document.myform2.gender.value == "") {
                document.getElementById("errorBox106").innerHTML = "Select Your gender";
                return false;
            }
			
			// if (document.myform2.marital_status.value == "") {
                // document.getElementById("errorBox107").innerHTML = "Select Your marital status";
                // return false;
            // }
			
			if (document.myform2.address.value == "") {
                document.getElementById("errorBox108").innerHTML = "Enter Your address";
                return false;
            }
			
			
			if (document.myform2.city.value == "") {
                document.getElementById("errorBox109").innerHTML = "Enter Your city";
                return false;
            }
			
			if (document.myform2.zip.value == "") {
                document.getElementById("errorBox110").innerHTML = "Enter Your zip code";
                return false;
            }
			
			if (document.myform2.mobile_no.value == "") {
                document.getElementById("errorBox111").innerHTML = "Enter Your contact no";
                return false;
            }
			
			if (document.myform2.your_email.value == "") {
                document.getElementById("errorBox112").innerHTML = "Enter Your Email";
                return false;
            }
			
			
			if (document.myform2.citizen_of_india.value == "") {
                document.getElementById("errorBox113").innerHTML = "Select Your Citizen Of India";
                return false;
            }
			
			if (document.myform2.date_of_result.value == "") {
                document.getElementById("errorBox114").innerHTML = "Enter Your Date of result";
                return false;
            }
			
			
			if (document.myform2.stream_applied.value == "") {
                document.getElementById("errorBox115").innerHTML = "Select Stream";
                return false;
            }
			
			if (document.myform2.amount.value == "") {
                document.getElementById("errorBox116").innerHTML = "Enter Your Fee";
                return false;
            }
			
			if (document.myform2.gurdian_name.value == "") {
                document.getElementById("errorBox117").innerHTML = "Enter your Guardian Name";
                return false;
            }
			
			
			if (document.myform2.phone_no.value == "") {
                document.getElementById("errorBox118").innerHTML = "Enter Your parent Mobile";
                return false;
            }
			
			if (document.myform2.parent_email.value == "") {
                document.getElementById("errorBox119").innerHTML = "Enter Your parent email";
                return false;
            }
			
			if (document.myform2.parent_address.value == "") {
                document.getElementById("errorBox120").innerHTML = "Enter Your Address";
                return false;
            }
			
			
			
			if (document.myform2.date_final.value == "") {
                document.getElementById("errorBox123").innerHTML = "Enter Your  Date";
                return false;
            }
			
			if (document.myform2.place_final.value == "") {
                document.getElementById("errorBox124").innerHTML = "Enter Your Place";
                return false;
            }
			
			if (document.myform2.applicant_signature.value == "") {
                document.getElementById("errorBox125").innerHTML = "Enter Your signature";
                return false;
            }
			
			if (document.myform2.your_message.value == "") {
                document.getElementById("errorBox126").innerHTML = "Enter Your Message";
                return false;
            }
			
			
			
			
			
			 
			
            var u_contact=document.myform2.mobile_no.value;
            if (isNaN(mobile_no)){
            document.getElementById("errorBox111").innerHTML="Please Enter your Contact";
            return false;
            }
            else{  
          return true;  
           }  
        }
    </script> 
<style>
     .vld{color:red;}
     </style> 




<?php

 $sql = "SELECT st_id ,your_email, status from enrolment_master where st_id ='$_SESSION[id_user]' and your_email='$_SESSION[user_name]'  ";

 //$sql = "SELECT st_id , status from enrolment_master where st_id ='$_SESSION[id_user]' ";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
   $row = mysqli_fetch_assoc($result);
        
   if($row["status"]=='1'){

   echo "<script>location.href='success_thank.php'</script>";
   //return true;
  } else if ($row["status"]==''){
    //echo "<script>location.href='application_form.php'</script>";
    //return false;
    }else{
    echo "<script>location.href='update_application_form.php'</script>";
   
    }
     
}else {
   //echo "<script>alert('Please fill all inputs')</script>";
}



?>










<?php
if(isset($_POST['enroll_submit'])){
$image = $_FILES['image']['name'];
$image_tmp1 = $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp1, "user-images/$image");
//$profile_image = $_POST['profile_image'];
$f_name = $_POST['f_name'];	
$m_name = $_POST['m_name'];
$l_name = $_POST['l_name'];
$dob = $_POST['dob'];
$name_of_place = $_POST['name_of_place'];
$gender = $_POST['gender'];
$marital_status = $_POST['marital_status'];
$address = $_POST['address'];
$city = $_POST['city'];
$state_a = $_POST['state_a'];
$zip = $_POST['zip'];
$mobile_no = $_POST['mobile_no'];
$your_email = $_POST['your_email'];
$citizen_of_india = $_POST['citizen_of_india'];
$date_of_result = $_POST['date_of_result'];
$name_of_examination = $_POST['name_of_examination'];

$year_passing = $_POST['year_passing'];
$board_university = $_POST['board_university'];
$of_marks = $_POST['of_marks'];
$name_of_examination_12 = $_POST['name_of_examination_12'];
$year_passing_12 = $_POST['year_passing_12'];
$board_university_12 = $_POST['board_university_12'];
$of_marks_12 = $_POST['of_marks_12'];
$name_of_examination_10 = $_POST['name_of_examination_10'];

$year_passing_10 = $_POST['year_passing_10'];
$board_university_10 = $_POST['board_university_10'];
$of_marks_10 = $_POST['of_marks_10'];
$stream_applied = $_POST['stream_applied'];
$amount = $_POST['amount'];
$payment_details = $_POST['payment_details'];
$gurdian_name = $_POST['gurdian_name'];
$phone_no = $_POST['phone_no'];
$parent_email = $_POST['parent_email'];
$parent_address = $_POST['parent_address'];
$parent_occupations = $_POST['parent_occupations'];
$parent_annualincome = $_POST['parent_annualincome'];

$i_hereby = $_POST['i_hereby'];
$date_final = $_POST['date_final'];
$place_final = $_POST['place_final'];
$applicant_signature = $_POST['applicant_signature'];
$your_message = $_POST['your_message'];
//$status = $_POST['status'];

//setcookie($f_name, $cookie_value,$l_name, time() + (86400 * 30), "/");

$insert_details = "insert into  enrolment_master (order_id,profile_image,st_id,f_name,m_name,l_name,dob,name_of_place,gender,marital_status,address,city,state_a,zip,mobile_no,your_email,citizen_of_india,
date_of_result,name_of_examination,year_passing,board_university,of_marks,name_of_examination_12,year_passing_12,board_university_12,
of_marks_12,name_of_examination_10,year_passing_10,board_university_10,of_marks_10,stream_applied,amount,payment_details,gurdian_name,phone_no,parent_email,parent_address,parent_occupations,parent_annualincome,i_hereby,date_final,place_final,
applicant_signature,your_message,created_on) 
values ('{$_SESSION['id_user']}','$image','{$_SESSION['id_user']}','$f_name','$m_name','$l_name','$dob','$name_of_place','$gender','$marital_status','$address','$city','$state_a','$zip',
'$mobile_no',
'$your_email','$citizen_of_india','$date_of_result','$name_of_examination','$year_passing','$board_university','$of_marks','$name_of_examination_12',
'$year_passing_12','$board_university_12','$of_marks_12','$name_of_examination_10','$year_passing_10','$board_university_10','$of_marks_10',
'$stream_applied','$amount','$payment_details','$gurdian_name','$phone_no','$parent_email',
'$parent_address','$parent_occupations','$parent_annualincome','$i_hereby','$date_final','$place_final','$applicant_signature',
'$your_message',NOW()) ";

 
//$insert_details="CALL st_insert('$st_name','$st_email','$st_contact','$st_password','','')";

$run_insert = mysqli_query($con, $insert_details);
if($run_insert){

if($payment_details=="Online")
	{
	//echo "<script>location.href='online_payment/payment.php'</script>"; 
	echo "<script>location.href='view_application.php'</script>";
	}
	else
	{
	echo "<script>alert('Some Technichal Issue')</script>";
	
	}
}
else{
echo "<script>alert('Some Technichal Error!!')</script>";
}
}
?>


<body oncontextmenu="return false;">

		<?php  include("header.php");?>

		<section id="content" class="no-padding">

			<div class="container">

				<div class="row no-margin">

					<div id="main" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 entry-content">

						<div class="profile-detail">

							<div class="header-title text-center">

                            	<img src="images/same_logo.png" alt="IGESAME">

                                <h4>
                                    4th Floor, Plot No.25/3, Knowledge Park-III, Greater Noida, Uttar Pradesh-201306<br>
                                    Approved by Director General of Civil Aviation , Ministry Of Civil Aviation, Govt Of Indian

                                </h4>

							</div>

                            <div class="row">
                                 <div class="col-xs-12">

									<div class="title-block mb40">

										<h4>Application Form</h4>

									</div>

                                    <p class="list2">

                                    	1. Before paying the application fee, please make sure that you fulfil all eligibility criteria as per details in the prospectus/Website.<br>

                                        2. The completed application form is to be sent to the admission incharge at the above address.

                                    </p>

                                </div>

                                <div class="divider"></div>

                            </div>

							<div class="row">
<form  method="post" class="form-horizontal form-label-left" enctype="multipart/form-data" name="myform2" onsubmit="return validateApp()">
								<div class="col-xs-12">

									<div class="form-horizontal form-label-left">

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														First Name  <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

														<div class="row">

															<div class="col-md-12">

												<input type="text" name="f_name" class="form-control" placeholder="First Name">
                                                                <span class="vld" id="errorBox101"></span>
															</div>

														</div>

														

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Middle Name

													</label>

												<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">
                                                    <input type="text" name="m_name"  class="form-control"  placeholder="Middle Name">
                                                                    
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Last Name  <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

											<input type="text" name="l_name" class="form-control" placeholder="Last Name">
                                                                 <span class="vld" id="errorBox103"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">D.O.B.</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

										<input type="text" name="dob" id="datepicker3" class="form-control" placeholder="DOB">
                                                    <span class="vld" id="errorBox104"></span>
													</div>

												</div>

											</div>

										</div>

                                        <div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Place of Birth <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<input type="text" name="name_of_place" class="form-control" placeholder="Place of Birth">
                                                                 <span class="vld" id="errorBox105"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

										<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Gender <span class="required">*</span>

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<label class="radio-inline">

									<input type="radio" name="gender" value="Male" class="radio">Male

														</label>

									<label class="radio-inline">

									<input type="radio" name="gender" value="Female" class="radio">Female

									</label>
									
									<label class="radio-inline"><span class="vld" id="errorBox106"></span></label>
                                                                                           
													</div>

												</div>

											</div>
                                                                        
										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

					<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">Marital Status
                                        
                                        </label>

						<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

						<label class="radio-inline">
                         <input type="radio" name="marital_status" value="Married" class="radio">Married
             </label>
              <label class="radio-inline">
               <input type="radio" name="marital_status" value="UnMarried" class="radio">UnMarried
              </label>
              <label class="radio-inline"><span class="vld" id="errorBox107"></span></label>
                </div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

			<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">Address  <span class="required">*</span>

													</label>

								<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<textarea rows="1" name="address" class="form-control" placeholder="Address"></textarea>
                                                               <span class="vld" id="errorBox108"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

			<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">City <span class="required">*</span></label>

				<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

				<input type="text" name="city" class="form-control" placeholder="City">
                                  <span class="vld" id="errorBox109"></span>
				</div>
                              </div>

			</div>

        <div class="col-xs-12 col-md-6 col-lg-6">

				<div class="row">

				<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">State <span class="required">*</span>
                                   </label>

				<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">
<select name="state_a" class="form-control">
<option>Choose State</option>
<option value="Andra Pradesh">Andra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Goa">Goa</option>

<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>

<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madya Pradesh">Madya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>


<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>

<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Tripura">Tripura</option>
<option value="Telangana">Telangana</option>
<option value="Uttaranchal">Uttaranchal</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>

<option value="West Bengal">West Bengal</option>
<option value="Andaman and Nicobar">Andaman and Nicobar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>

<option value="Delhi">Delhi</option>
<option value="Lakshadeep">Lakshadeep</option>
<option value="Pondicherry">Pondicherry</option>
 


</select>
														
														 
<span class="arrow"><i class="fa fa-sort"></i></span>

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

											<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Pin Code <span class="required">*</span>

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="zip" class="form-control" placeholder="Zip">
									<span class="vld" id="errorBox110"></span>

													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

										Phone/Mobile No. <span class="required">*</span>

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="mobile_no" class="form-control" maxlength="10" placeholder="Phone/Mobile No.">
                                                                        <span class="vld" id="errorBox111"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Your Email <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">
													<?php 
  $view_posts = "select st_email from std_registration  where st_email = '$_SESSION[user_name]' ";
	$run_posts = mysqli_query($con, $view_posts);
	while($row_posts = mysqli_fetch_array($run_posts)){
	?>

		<input type="text" name="your_email" value="<?php echo $row_posts['st_email']; ?>" class="form-control" placeholder="Your Email" readonly>
										<?php } ?> 
                                                                   <span class="vld" id="errorBox1121"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Citizen Of India <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

										<label class="radio-inline">

							<input type="radio" name="citizen_of_india" value="Yes" class="radio">Yes

										</label>

							<label class="radio-inline">

						<input type="radio" name="citizen_of_india" value="No" class="radio" >No
                                                       </label>
                                       <label class="radio-inline"> <span class="vld" id="errorBox113"></span></label>
													</div>

												</div>

											</div>

										</div>

                                        <div class="divider"></div>

                                        <div class="form-group row">

											<div class="col-xs-12 col-md-12 col-lg-11">

												<div class="row">

									<label class="control-label col-lg-8 col-md-8 col-sm-8 col-xs-12">

		Educational Qualification of student: [10+2]or equivalent Passed [10+2]or equivalent appeared If [10+2]or equivalent appeared,then mention likely date of 
		result
                                                                            </label>

											<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

									<input type="text" id="datepicker2" name="date_of_result" class="form-control" placeholder="Date">
                                             <span class="vld" id="errorBox114"></span>
													</div>

												</div>

											</div>

										</div>

                                        <div class="form-group row">

                                        	<div class="col-xs-12">

                                            	<div class="cart">

													<table class="data-table table-striped">

														<thead>

															<tr>

											<th class="column-title">Name of Examination Passed</th>

											<th class="column-title">Year Passing</th>

											<th class="column-title">Board/University</th>

										         <th class="column-title">% of Marks</th>

															</tr>

														</thead>

														<tbody>

															<tr>

						<td data-title="Name of Examination Passed" class="a-center">

						<input type="text" name="name_of_examination" class="form-control" placeholder="Graduation">
                                                     </td>

						<td data-title="Year Passing" class="a-left">

					      <input type="text" id="" name="year_passing" class="form-control" placeholder="Year of passing">

						</td>

					<td data-title="Board/University" class="a-left">

					<input type="text" name="board_university" class="form-control" placeholder="Board/University ">

					</td>

				        <td data-title="% of Marks" class="a-left">

					<input type="text" name="of_marks" class="form-control" placeholder="% of Marks">

				         </td>

					</tr>

				     <tr>

					<td data-title="Name of Examination Passed" class="a-center">

		                 <input type="text" name="name_of_examination_12" class="form-control" placeholder="12th">

				</td>

				<td data-title="Year Passing" class="a-left">

				<input type="text" id="" name="year_passing_12" class="form-control" placeholder="Year Passing">

			         </td>

				<td data-title="Board/University" class="a-left">

				<input type="text" name="board_university_12" class="form-control"  placeholder="Board/University">

				</td>

				<td data-title="% of Marks" class="a-left">

			        <input type="text" name="of_marks_12" class="form-control" placeholder="% of Marks">

				</td>

															</tr>

															<tr>

				<td data-title="Name of Examination Passed" class="a-center">

			 <input type="text" name="name_of_examination_10" class="form-control" placeholder="10th">

				</td>

				<td data-title="Year Passing" class="a-left">

				<input type="text" id="" name="year_passing_10" class="form-control" placeholder="Year Passing">

				</td>

				<td data-title="Board/University" class="a-left">

				<input type="text" name="board_university_10" class="form-control" placeholder="Board/University">

				</td>

				<td data-title="% of Marks" class="a-left">

				<input type="text" name="of_marks_10" class="form-control" placeholder="% of Marks">

																</td>

															</tr>

															

														</tbody>

													</table>

												</div>

											</div>

										</div>

										<div class="divider"></div>

									</div>

									

									<div class="form-horizontal form-label-left">

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

								<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">
                                                                  Stream applied for <span class="required">*</span>

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

											<label class="radio-inline">

							<input type="radio" name="stream_applied" value="Mechanical" class="radio">Mechanical
                                                                         </label>

								<label class="radio-inline">

						<input type="radio" name="stream_applied" value="Avionics" class="radio">Avionics
                                                                        </label>
                                                  <span class="vld" id="errorBox115"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

						<label class="control-label col-lg-7 col-md-4 col-sm-3 col-xs-12">

										Non-Refundable Application fees Rs.1000/-

													</label>

									<div class="col-lg-4 col-md-6 col-sm-9 col-xs-12">

							<input type="text" name="amount" value="1000" class="form-control" readonly>
							
                                            <span class="vld" id="errorBox116"></span>
													</div>

												</div>

											</div>

										</div>

										

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

										Payment Details <span class="required">*</span>

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

														<label class="radio-inline">

   <label class="radio-inline">

	<input type="radio"  id="payment_details"  name="payment_details" value="Online" class="radio" checked>

															Online

														</label>

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

										<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Name of Parent/ Guardian

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<input type="text" name="gurdian_name" class="form-control" placeholder="Name of Parent/ Guardian">
                                              <span class="vld" id="errorBox117"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

								<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

											Phone/Mobile No. <span class="required">*</span>

											</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="phone_no" class="form-control" maxlength="10" placeholder="Phone/Mobile No.">
                                               <span class="vld" id="errorBox118"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

										<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

											Parent Email <span class="required">*</span>

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="parent_email" class="form-control" placeholder="Parent Email">
                                          <span class="vld" id="errorBox119"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

													Address  <span class="required">*</span>

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<textarea rows="1" name="parent_address" class="form-control" placeholder="Parent Address"></textarea>
                                                 <span class="vld" id="errorBox120"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

										<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Occupations

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<input type="text" name="parent_occupations" class="form-control" placeholder="Occupations">
                                         <span class="vld" id="errorBox121"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Annual Income

													</label>

								<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

							<input type="text" name="parent_annualincome" class="form-control" placeholder="Annual Income">
                                        
													</div>

												</div>

											</div>

										</div>

										

										

										<div class="form-group row">

											<div class="col-xs-12 col-md-12 col-lg-12">

												<div class="row">

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

														<label class="radio-inline">

										<input type="radio" name="i_hereby" value="yes" class="radio" checked>

						I hereby declare that the above information is complete and true to the best of my knowledge.	

														</label>

													</div>

												</div>

											</div>

										</div>

										

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

									<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">
                                                                          Date

													</label>

							<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

						<input type="text" id="datepicker7" name="date_final" class="form-control" placeholder="Date">
                             <span class="vld" id="errorBox123"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Place

													</label>

										<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

										<input type="text" name="place_final" class="form-control" placeholder="Place">
                                             <span class="vld" id="errorBox124"></span>
													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

													<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Signature

													</label>

													<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<input type="text" name="applicant_signature" class="form-control" placeholder="Signature">
                                                    <span class="vld" id="errorBox125"></span>
													</div>

												</div>

											</div>

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

								<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

														Your Message

													</label>

									<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

									<textarea rows="3" name="your_message" class="form-control" placeholder="Your Message"></textarea>
									<span class="vld" id="errorBox126"></span>
								

													</div>

												</div>

											</div>

										</div>

										<div class="form-group row">

											<div class="col-xs-12 col-md-6 col-lg-6">

												<div class="row">

							<label class="control-label col-lg-4 col-md-4 col-sm-3 col-xs-12">

								Upload Photo <span class="required">*</span>

										</label>

								<div class="col-lg-7 col-md-6 col-sm-9 col-xs-12">

								<input type="file" name="image"  placeholder="Profile image" value="">
                                    
													</div>

												</div>

											</div>

										</div>

										<hr class="full-width">

									</div>

									 </div>

								<div class="col-xs-12 col-md-12">

									<div class="buttons-set">

					<input type="submit" name="enroll_submit" class="ns-button" value="Submit">

									</div>

								</div>
</form>
							</div>

						</div>

					</div>

				</div>

			</div>

		</section>
      <?php include("footer.php");?>	

		 </body>

	

<script language="JavaScript">
  /**
    * Disable right-click of mouse, F12 key, and save key combinations on page
    * By Arthur Gareginyan (arthurgareginyan@gmail.com)
    * For full source code, visit http://www.mycyberuniverse.com
    */
  window.onload = function() {
    document.addEventListener("contextmenu", function(e){
      e.preventDefault();
    }, false);
    document.addEventListener("keydown", function(e) {
    //document.onkeydown = function(e) {
      // "I" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
        disabledEvent(e);
      }
      // "J" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
        disabledEvent(e);
      }
      // "S" key + macOS
      if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
        disabledEvent(e);
      }
      // "U" key
      if (e.ctrlKey && e.keyCode == 85) {
        disabledEvent(e);
      }
      // "F12" key
      if (event.keyCode == 123) {
        disabledEvent(e);
      }
    }, false);
    function disabledEvent(e){
      if (e.stopPropagation){
        e.stopPropagation();
      } else if (window.event){
        window.event.cancelBubble = true;
      }
      e.preventDefault();
      return false;
    }
  };
</script>

	<script src="https://fengyuanchen.github.io/js/common.js"></script>
  <script src="js/js/datepicker.js"></script>
  <script src="js/js/main.js"></script>

